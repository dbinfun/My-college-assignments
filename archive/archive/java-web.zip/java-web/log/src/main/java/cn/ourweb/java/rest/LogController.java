package cn.ourweb.java.rest;

import cn.ourweb.java.dto.LogDto;
import cn.ourweb.java.entity.Log;
import cn.ourweb.java.service.LogService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/log")
@AllArgsConstructor
public class LogController {
    private final LogService logService;
    @PreAuthorize("@pm.check('log:list')")
    @GetMapping
    public ResponseEntity<IPage<LogDto>> queryAll(Page<Log> page){
        IPage<LogDto> page1 = logService.queryAll(page);
        return new ResponseEntity<>(page1, HttpStatus.OK);
    }
}
