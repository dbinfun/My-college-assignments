package cn.ourweb.java.dto;

import cn.ourweb.java.annotation.Query;
import lombok.Data;

@Data
public class LogQueryCriteria {
    @Query(type = Query.Type.EQUAL)
    private Long id;
}
