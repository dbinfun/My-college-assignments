package cn.ourweb.java.service;

import cn.ourweb.java.dto.LogDto;
import cn.ourweb.java.entity.Log;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.scheduling.annotation.Async;

import java.sql.Timestamp;

public interface LogService extends IService<Log> {
    @Async
    void saveLog(Log log, ProceedingJoinPoint joinPoint);
    
    /**
     * 清除日志
     * @param begin 开始时间
     * @param end 结束时间
     */
    void cleanLog(Timestamp begin, Timestamp end);

    IPage<LogDto> queryAll(Page<Log> page);
}
