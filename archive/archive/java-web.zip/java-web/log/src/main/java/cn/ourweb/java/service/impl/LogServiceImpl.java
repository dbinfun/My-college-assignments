package cn.ourweb.java.service.impl;

import cn.ourweb.java.entity.Log;
import cn.ourweb.java.mapper.LogMapper;
import cn.ourweb.java.service.mapstruct.LogMapperS;
import cn.ourweb.java.service.LogService;
import com.alibaba.fastjson2.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@AllArgsConstructor
public class LogServiceImpl extends ServiceImpl<LogMapper, Log> implements LogService {
    public final LogMapperS logMapperS;
    public final LogMapper logMapper;
    @Override
    public void saveLog(Log log, ProceedingJoinPoint joinPoint){
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        cn.ourweb.java.annotation.Log sysLog = method.getAnnotation(cn.ourweb.java.annotation.Log.class);
        String methodName = joinPoint.getTarget().getClass().getName() + "." + signature.getName() + "()";
        String params = getParameter(method,joinPoint.getArgs());
        log.setDescription(sysLog.value());
        log.setParams(params);
        log.setMethodName(methodName);
        this.save(log);
    }

    private String getParameter(Method method, Object[] args) {
        List<Object> argList = new ArrayList<>();
        Parameter[] parameters = method.getParameters();
        for (int i = 0; i < parameters.length; i++) {
            //将RequestBody注解修饰的参数作为请求参数
            RequestBody requestBody = parameters[i].getAnnotation(RequestBody.class);
            if (requestBody != null) {
                argList.add(args[i]);
            }
            //将RequestParam注解修饰的参数作为请求参数
            RequestParam requestParam = parameters[i].getAnnotation(RequestParam.class);
            if (requestParam != null) {
                Map<String, Object> map = new HashMap<>();
                String key = parameters[i].getName();
                if (!StringUtils.isEmpty(requestParam.value())) {
                    key = requestParam.value();
                }
                map.put(key, args[i]);
                argList.add(map);
            }
        }
        if (argList.size() == 0) {
            return "";
        }
        return argList.size() == 1 ? JSONObject.toJSONString(argList.get(0)) : JSONObject.toJSONString(argList);
    }
    
    public void cleanLog(Timestamp begin, Timestamp end){
        LambdaUpdateWrapper<Log> wrapper = new LambdaUpdateWrapper<>();
        if(begin!=null){
            wrapper.and(time->time.ge(Log::getRequestTime,begin));
        }
        if(end!=null){
            wrapper.and(time->time.le(Log::getRequestTime,end));
        }
        remove(wrapper);
    }

    @Override
    public IPage queryAll(Page<Log> page) {
        IPage<Log> p = logMapper.selectPage(page,new QueryWrapper<>());
        p.convert(logMapperS::toDto);
        return p;
    }
}
