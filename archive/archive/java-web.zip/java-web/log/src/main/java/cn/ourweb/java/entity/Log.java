package cn.ourweb.java.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.sql.Timestamp;

@Data
@TableName("sys_log")
public class Log implements Serializable {
    @TableId(value = "log_id",type = IdType.AUTO)
    private Long id;
    private Integer type;
    private Long userId;
    private String username;
    private String description;
    private String browser;
    private String address;
    @TableField("`method`")
    private String methodName;
    private String params;
    private String exception;
    private Timestamp requestTime;//请求时间
    private Timestamp elapsedTime;//请求耗时
    public Log(){}
    public Log(Integer type,Timestamp requestTime,Timestamp elapsedTime){
        this.type=type;
        this.requestTime=requestTime;
        this.elapsedTime=elapsedTime;
    }
}
