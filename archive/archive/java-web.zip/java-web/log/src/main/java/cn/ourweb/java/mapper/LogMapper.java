package cn.ourweb.java.mapper;

import cn.ourweb.java.entity.Log;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;
@Repository
public interface LogMapper extends BaseMapper<Log> {
}
