package cn.ourweb.java.dto;
import lombok.Data;

import java.io.Serializable;
import java.sql.Timestamp;

@Data
public class LogDto implements Serializable {
    private Long id;
    private Integer type;
    private Long userId;
    private String username;
    private String description;
    private String browser;
    private String address;
    private String methodName;
    private String params;
    private String exception;
    private Timestamp requestTime;//请求时间
    private Timestamp elapsedTime;//请求耗时
    public LogDto(){}
}
