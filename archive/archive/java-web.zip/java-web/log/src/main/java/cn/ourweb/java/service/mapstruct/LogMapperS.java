package cn.ourweb.java.service.mapstruct;

import cn.ourweb.java.base.BaseMapperS;
import cn.ourweb.java.dto.LogDto;
import cn.ourweb.java.entity.Log;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface LogMapperS extends BaseMapperS<LogDto, Log> {
}
