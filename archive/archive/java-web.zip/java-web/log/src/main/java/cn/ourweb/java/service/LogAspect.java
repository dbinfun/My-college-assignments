package cn.ourweb.java.service;

import cn.ourweb.java.entity.Log;
import cn.ourweb.java.util.SecurityUtil;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;


@Aspect
@Component
@Slf4j
//@AllArgsConstructor
public class LogAspect {
    private final LogService logService;
    @Autowired
    public LogAspect(LogService logService) {
        this.logService = logService;
    }
    private final ThreadLocal<Long> currentTime = new ThreadLocal<>();
    @Pointcut("@annotation(cn.ourweb.java.annotation.Log)")
    public void logPointCut() {
    }
    @Around("logPointCut()")
    public Object around(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        Object result;
        currentTime.set(System.currentTimeMillis());
        result = proceedingJoinPoint.proceed();
        Log log = new Log(0,new Timestamp(currentTime.get()),new Timestamp(System.currentTimeMillis()-currentTime.get()));
        currentTime.remove();
        Long userId = null;
        String username = null;
        UserDetails user = SecurityUtil.getCurrentUser();
        username = user.getUsername();
        userId = SecurityUtil.getCurrentUserId();
        log.setUsername(username);
        log.setUserId(userId);
        HttpServletRequest request = ((ServletRequestAttributes) (RequestContextHolder.currentRequestAttributes())).getRequest();
        String addr = request.getRemoteAddr();
        String browser = request.getHeader("User-Agent");
        log.setAddress(addr);
        log.setBrowser(browser);
        //异步保存信息,用户相关信息都需要在此之前,否则上下文信息失效。
        logService.saveLog(log,proceedingJoinPoint);
        return result;
    }
    @AfterThrowing(pointcut = "logPointCut()",throwing = "e")
    public void logAffterThrowing(JoinPoint proceedingJoinPoint, Throwable e) {
        Log log = new Log(1,new Timestamp(currentTime.get()),new Timestamp(System.currentTimeMillis()-currentTime.get()));
        currentTime.remove();
        log.setException(e.getMessage());
        e.printStackTrace();
        logService.saveLog(log,(ProceedingJoinPoint)proceedingJoinPoint);
    }
}
