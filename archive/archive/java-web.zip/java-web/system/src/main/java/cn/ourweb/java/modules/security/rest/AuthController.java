package cn.ourweb.java.modules.security.rest;

import cn.ourweb.java.annotation.Log;
import cn.ourweb.java.base.Result;
import cn.ourweb.java.config.PermissionConfig;
import cn.ourweb.java.config.bean.SystemProperties;
import cn.ourweb.java.modules.security.domain.AuthEntity;
import cn.ourweb.java.modules.security.dto.JwtUserDto;
import cn.ourweb.java.modules.security.security.TokenProvider;
import cn.ourweb.java.util.RsaUtil;
import cn.ourweb.java.util.SecurityUtil;
import com.alibaba.fastjson2.JSONObject;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

@RequestMapping("/auth")
@AllArgsConstructor
@RestController
public class AuthController {
    private final AuthenticationManagerBuilder authenticationManagerBuilder;
    private final TokenProvider tokenProvider;
    private final SystemProperties systemProperties;
    private final PermissionConfig permissionConfig;
    @Log("用户登录")
    @PostMapping("/login")
    public Result login(@RequestBody @Valid AuthEntity authEntity, HttpServletRequest request, HttpServletResponse response){
        String password = authEntity.getPassword();
        String username = authEntity.getUsername();
        try {
            password = RsaUtil.decryptByPrivateKey(systemProperties.getRsaPrivateKey(), password);
        }catch (Exception e){
            return Result.error("密码错误");
        }
        UsernamePasswordAuthenticationToken authenticationToken =
                new UsernamePasswordAuthenticationToken(username, password);
        Authentication authentication = authenticationManagerBuilder.getObject().authenticate(authenticationToken);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        // 生成令牌
        String token = tokenProvider.createToken(username);
        JwtUserDto jwtUserDto = (JwtUserDto) authentication.getPrincipal();
        // 保存在线信息
        tokenProvider.saveToken(token,jwtUserDto,request);
        //踢掉以前的token.
        tokenProvider.removeUser(username);
        System.out.println(SecurityUtil.getCurrentUser());
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("user",jwtUserDto.getUser());
        jsonObject.put("token",token);
        return Result.ok(jsonObject);
    }
    @Log("获取个人权限")
    @GetMapping(value="/myPermission")
    public ResponseEntity myPermission(){
        return new ResponseEntity(permissionConfig.getPermissions(), HttpStatus.OK);
    }
}
