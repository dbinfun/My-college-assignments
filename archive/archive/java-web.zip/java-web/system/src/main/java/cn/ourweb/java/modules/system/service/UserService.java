package cn.ourweb.java.modules.system.service;

import cn.ourweb.java.modules.system.dto.UserDto;
import cn.ourweb.java.modules.system.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

public interface UserService/* extends IService<User>*/ {
    UserDto getOneByUsername(String username);
}
