package cn.ourweb.java.modules.security.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class OnlineUserDto implements Serializable {
    private String username;
    private String nickName;
    private String ip;
    public OnlineUserDto(String username, String nickName, String ip){
        this.username = username;
        this.nickName = nickName;
        this.ip = ip;
    }
}
