package cn.ourweb.java.modules.system.dto;

import lombok.Data;

import java.util.List;

@Data
public class RoleDto {
    Long id;
    String name;
    String description;
    List<PermissionDto> permissions;
}
