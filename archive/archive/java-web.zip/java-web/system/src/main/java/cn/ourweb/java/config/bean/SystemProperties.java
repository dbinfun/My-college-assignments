package cn.ourweb.java.config.bean;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "system.properties")
@Data
public class SystemProperties {
    private String rsaPublicKey;
    private String rsaPrivateKey;
}
