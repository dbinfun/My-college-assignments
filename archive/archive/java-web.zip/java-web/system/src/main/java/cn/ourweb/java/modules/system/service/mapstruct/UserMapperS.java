package cn.ourweb.java.modules.system.service.mapstruct;

import cn.ourweb.java.base.BaseMapperS;
import cn.ourweb.java.modules.system.dto.UserDto;
import cn.ourweb.java.modules.system.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface UserMapperS extends BaseMapperS<UserDto, User> {
}
