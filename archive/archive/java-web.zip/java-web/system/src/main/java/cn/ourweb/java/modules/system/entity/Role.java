package cn.ourweb.java.modules.system.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.List;

@Data
@TableName(value = "sys_role")
public class Role {
    @TableId(value = "role_id")
    Long id;
    @TableField(value = "role_name")
    String name;
    @TableField(value = "role_description")
    String description;
    @TableField(exist = false)
    List<Permission> permissions;

}
