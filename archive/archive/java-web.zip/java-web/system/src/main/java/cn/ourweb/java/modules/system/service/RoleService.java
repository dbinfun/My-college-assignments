package cn.ourweb.java.modules.system.service;

import cn.ourweb.java.modules.system.dto.RoleDto;
import cn.ourweb.java.modules.system.dto.UserDto;
import org.springframework.security.core.GrantedAuthority;

import java.util.List;

public interface RoleService {
    List<Long> findPermissionIdsByRoleId(Long roleId);
    RoleDto findByRoleId(Long roleId);
    List<GrantedAuthority> mapToGrantedAuthorities(UserDto user);
}
