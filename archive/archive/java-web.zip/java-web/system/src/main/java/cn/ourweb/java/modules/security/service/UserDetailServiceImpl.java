package cn.ourweb.java.modules.security.service;

import cn.ourweb.java.cache.CaffeineFactory;
import cn.ourweb.java.exception.BadRequestException;
import cn.ourweb.java.modules.security.dto.JwtUserDto;
import cn.ourweb.java.modules.system.dto.PermissionDto;
import cn.ourweb.java.modules.system.dto.RoleDto;
import cn.ourweb.java.modules.system.dto.UserDto;
import cn.ourweb.java.modules.system.service.PermissionService;
import cn.ourweb.java.modules.system.service.RoleService;
import cn.ourweb.java.modules.system.service.UserService;
import com.github.benmanes.caffeine.cache.Cache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserDetailServiceImpl implements UserDetailsService {
    private final UserService userService;
    private final RoleService roleService;
    private final PermissionService permissionService;
    @Autowired
    public UserDetailServiceImpl(UserService userService,RoleService roleService,PermissionService permissionService) {
        this.userService = userService;
        this.roleService = roleService;
        this.permissionService = permissionService;

    }
    private final static Cache<String, JwtUserDto> loginCache = CaffeineFactory.getCache(3600,50);
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        JwtUserDto JwtUserDto = loginCache.getIfPresent(username);
        if(JwtUserDto==null){
            UserDto userDto = userService.getOneByUsername(username);
            if(userDto==null){
                throw new BadCredentialsException("");
            }
            RoleDto roleDto = roleService.findByRoleId(userDto.getRoleId());
            if(roleDto!=null){
                List<Long> permissionIds = roleService.findPermissionIdsByRoleId(userDto.getRoleId());
                //查询权限
                List<PermissionDto> permissionDtos = permissionIds.size()==0?new ArrayList<>():permissionService.findPermissionsOnIdIn(permissionIds);
                roleDto.setPermissions(permissionDtos);
                userDto.setRole(roleDto);
            }
            //此处留待后面添加权限
            JwtUserDto = new JwtUserDto(userDto,roleService.mapToGrantedAuthorities(userDto));
            loginCache.put(username,JwtUserDto);//用户缓存
        }
        if(!JwtUserDto.getUser().isEnabled()){
            throw new BadRequestException("账号被禁用");
        }
        return JwtUserDto;
    }
}
