package cn.ourweb.java.modules.system.service.impl;

import cn.ourweb.java.modules.system.dto.PermissionDto;
import cn.ourweb.java.modules.system.dto.RoleDto;
import cn.ourweb.java.modules.system.dto.UserDto;
import cn.ourweb.java.modules.system.entity.Role;
import cn.ourweb.java.modules.system.mapper.RoleMapper;
import cn.ourweb.java.modules.system.service.RoleService;
import cn.ourweb.java.modules.system.service.mapstruct.RoleMapperS;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements RoleService {
    private RoleMapper roleMapper;
    private RoleMapperS roleMapperS;
    @Override
    public List<Long> findPermissionIdsByRoleId(Long roleId) {
        return roleMapper.getPermissionsIdByRoleId(roleId);
    }

    @Override
    public RoleDto findByRoleId(Long roleId) {
        return roleMapperS.toDto(getById(roleId));
    }

    @Override
    public List<GrantedAuthority> mapToGrantedAuthorities(UserDto user) {
        Set<String> permissions = new HashSet<>();
        // 如果是管理员直接返回
        if (user.isAdmin()) {
            permissions.add("admin");
            return permissions.stream().map(SimpleGrantedAuthority::new)
                    .collect(Collectors.toList());
        }
        if(user.getRole()==null||user.getRole().getPermissions()==null){
            return new ArrayList<>();
        }
        return user.getRole().getPermissions().stream().map(PermissionDto::getPermission).map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());
    }
}
