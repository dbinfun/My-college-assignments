package cn.ourweb.java.modules.system.service;

import cn.ourweb.java.modules.system.dto.PermissionDto;

import java.util.List;

public interface PermissionService {
    List<PermissionDto> findPermissionsOnIdIn(List<Long> ids);
}
