package cn.ourweb.java.modules.system.mapper;

import cn.ourweb.java.modules.system.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface UserMapper extends BaseMapper<User> {
}
