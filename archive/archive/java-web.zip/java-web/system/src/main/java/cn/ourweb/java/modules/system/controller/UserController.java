package cn.ourweb.java.modules.system.controller;

import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/test")
@AllArgsConstructor
public class UserController {
    @GetMapping
    public Map test(){
        Map<String,String> map = new HashMap<String,String>();
        map.put("username","test");
        return map;
    }
    @GetMapping("/test")
    public Map test2(){
        Map<String,String> map = new HashMap<String,String>();
        map.put("username","test");
        return map;
    }
}
