package cn.ourweb.java.modules.system.service.mapstruct;

import cn.ourweb.java.base.BaseMapperS;
import cn.ourweb.java.modules.system.dto.RoleDto;
import cn.ourweb.java.modules.system.entity.Role;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(uses = {PermissionMapperS.class},componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface RoleMapperS extends BaseMapperS<RoleDto, Role> {
}
