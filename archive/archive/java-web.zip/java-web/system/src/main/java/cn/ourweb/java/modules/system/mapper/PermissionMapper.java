package cn.ourweb.java.modules.system.mapper;

import cn.ourweb.java.modules.system.entity.Permission;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface PermissionMapper extends BaseMapper<Permission> {
}
