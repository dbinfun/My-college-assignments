package cn.ourweb.java.modules.system.dto;

import lombok.Data;

@Data
public class PermissionDto {
    private Long id;
    private String name;
    private String permission;
    private String description;
}
