package cn.ourweb.java;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableAsync;
@EnableAspectJAutoProxy(proxyTargetClass = true)//开启 aop
@MapperScan("cn.ourweb.java.**.mapper")
@SpringBootApplication
@EnableAsync
public class AppRun {
    public static void main(String[] args) {
        SpringApplication.run(AppRun.class,args);
    }
}
