package cn.ourweb.java.modules.system.service.mapstruct;

import cn.ourweb.java.base.BaseMapperS;
import cn.ourweb.java.modules.system.dto.PermissionDto;
import cn.ourweb.java.modules.system.entity.Permission;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface PermissionMapperS extends BaseMapperS<PermissionDto,Permission> {
}
