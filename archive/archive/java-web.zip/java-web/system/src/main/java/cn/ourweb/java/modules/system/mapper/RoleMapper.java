package cn.ourweb.java.modules.system.mapper;

import cn.ourweb.java.modules.system.entity.Role;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface RoleMapper extends BaseMapper<Role> {
    @Select(value = "select `permission_id` from sys_role_permission where `role_id` = #{role_id}")
    List<Long> getPermissionsIdByRoleId(Long roleId);

}
