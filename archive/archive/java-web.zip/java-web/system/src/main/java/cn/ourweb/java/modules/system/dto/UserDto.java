package cn.ourweb.java.modules.system.dto;

import com.alibaba.fastjson2.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

@Data
public class UserDto {
    private Long id;
    private String username;
    @JSONField(serialize = false)
    private String password;
    private String nickName;
    @JSONField(serialize = false)
    private boolean isAdmin;
    private boolean isEnabled;
    private Long roleId;
    private RoleDto role;
}
