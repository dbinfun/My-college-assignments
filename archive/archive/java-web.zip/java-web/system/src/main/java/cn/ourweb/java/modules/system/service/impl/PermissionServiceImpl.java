package cn.ourweb.java.modules.system.service.impl;

import cn.ourweb.java.modules.system.dto.PermissionDto;
import cn.ourweb.java.modules.system.entity.Permission;
import cn.ourweb.java.modules.system.mapper.PermissionMapper;
import cn.ourweb.java.modules.system.service.PermissionService;
import cn.ourweb.java.modules.system.service.mapstruct.PermissionMapperS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
@AllArgsConstructor
@Service
public class PermissionServiceImpl extends ServiceImpl<PermissionMapper, Permission> implements PermissionService {
    private final PermissionMapper permissionMapper;
    private final PermissionMapperS permissionMapperS;
    @Override
    public List<PermissionDto> findPermissionsOnIdIn(List<Long> ids) {
        LambdaQueryWrapper<Permission> wrapper = new QueryWrapper<Permission>().lambda();
        wrapper.in(Permission::getId,ids);
        return permissionMapperS.toDto(permissionMapper.selectList(wrapper));
    }
}
