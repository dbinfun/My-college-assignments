package cn.ourweb.java.modules.system.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName(value = "sys_permission")
public class Permission {
    @TableId(value = "permission_id")
    private Long id;
    private String name;
    private String permission;
    private String description;
}
