package cn.ourweb.java.modules.system.service.impl;

import cn.ourweb.java.modules.system.dto.UserDto;
import cn.ourweb.java.modules.system.entity.User;
import cn.ourweb.java.modules.system.mapper.UserMapper;
import cn.ourweb.java.modules.system.service.mapstruct.UserMapperS;
import cn.ourweb.java.modules.system.service.UserService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    public final UserMapper userMapper;
    public final UserMapperS userMapperS;
    @Override
    public UserDto getOneByUsername(String username) {
        LambdaQueryWrapper<User> lambdaQueryWrapper = new QueryWrapper<User>().lambda().eq(User::getUsername,username);
        User user = userMapper.selectOne(lambdaQueryWrapper);
        return userMapperS.toDto(user);
    }
}
