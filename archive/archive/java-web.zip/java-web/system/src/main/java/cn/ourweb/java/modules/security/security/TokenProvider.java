package cn.ourweb.java.modules.security.security;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.ourweb.java.cache.RedisUtil;
import cn.ourweb.java.modules.security.config.JwtProperties;
import cn.ourweb.java.modules.security.dto.JwtUserDto;
import cn.ourweb.java.modules.security.dto.OnlineUserDto;
import com.alibaba.fastjson2.JSONObject;
import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;

import javax.annotation.PostConstruct;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.security.Key;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Configuration
@Data
@Slf4j
public class TokenProvider implements InitializingBean {
    private JwtParser jwtParser;
    private JwtBuilder jwtBuilder;
    private RedisUtil redisUtil;
    private final JwtProperties jwtProperties;
    private static String removeTokenPrefix;
    public TokenProvider(JwtProperties jwtProperties, RedisUtil redisUtil){
        this.jwtProperties = jwtProperties;
        this.redisUtil = redisUtil;
    }
    @PostConstruct
    public void init(){
        removeTokenPrefix = jwtProperties.getTokenPrefix()+"eyJhbGciOiJIUzI1NiJ9";
    }
    @Override
    public void afterPropertiesSet() {
        byte[] keyBytes = Decoders.BASE64.decode(jwtProperties.getBase64Secret());
        Key key = Keys.hmacShaKeyFor(keyBytes);
        jwtParser = Jwts.parserBuilder()
                .setSigningKey(key)
                .build();
        jwtBuilder = Jwts.builder()
                .signWith(key, SignatureAlgorithm.HS256);//此处与removeToken相对应.
    }
    public String createToken(String username){
        return jwtBuilder.setId(UUID.randomUUID().toString())
                .claim("user",username)
                .setSubject(username)
                .compact();
    }
    public Claims parseToken(String token){
        return jwtParser.parseClaimsJws(token)
                .getBody();
    }

    /**
     * 从请求获取token
     * @param request request
     * @return token
     */
    public String getToken(HttpServletRequest request){
        String token = request.getHeader("token");
        if(!StrUtil.isBlank(token)){
            return token;
        }
        Cookie[] cookies = request.getCookies();
        if(cookies==null||cookies.length==0){
            return null;
        }
        for(Cookie cookie : cookies){
            if(cookie.getName().equals("token")){
                return cookie.getValue();
            }
        }
        return null;
    }
    Authentication getAuthentication(String token) {
        Claims claims = parseToken(token);
        User principal = new User(claims.getSubject(), "******", new ArrayList<>());
        return new UsernamePasswordAuthenticationToken(principal, token, new ArrayList<>());
    }

    public void checkRenewal(String token) {
        // 判断是否续期token,计算token的过期时间
        long time = redisUtil.getExpire(jwtProperties.getTokenPrefix() + token) * 1000;
        Date expireDate = DateUtil.offset(new Date(), DateField.MILLISECOND, (int) time);
        // 判断当前时间与过期时间的时间差
        long differ = expireDate.getTime() - System.currentTimeMillis();
        // 如果在续期检查的范围内，则续期
        if (differ <= jwtProperties.getDetect()) {
            long renew = time + jwtProperties.getRenew();
            redisUtil.expire(jwtProperties.getTokenPrefix() + token, renew, TimeUnit.MILLISECONDS);
        }
    }

    public OnlineUserDto getOnlineUser(String token){
        return (OnlineUserDto) redisUtil.get(jwtProperties.getTokenPrefix()+token);
    }

    public void saveToken(String token, JwtUserDto jwtUserDto,HttpServletRequest request){
        OnlineUserDto onlineUserDto = new OnlineUserDto(jwtUserDto.getUsername()
                ,jwtUserDto.getUser().getNickName(),
                request.getRemoteAddr());//此项目不适用nginx进行反向代理,所以可以直接获取真实ip
        redisUtil.set(jwtProperties.getTokenPrefix()+token,onlineUserDto);
    }

    /**
     * 根据新token踢掉旧token
     * @param saveToken 用户的新token
     */
    @Async
    public void removeToken(String saveToken){
        saveToken = jwtProperties.getTokenPrefix()+saveToken;
        final int ch = removeTokenPrefix.length()+1;
        String username;
        try {
            username = JSONObject.parseObject(Base64.decodeStr(saveToken.substring(ch,saveToken.indexOf('.',ch)))).getString("user");
        }catch (Exception e){
            e.printStackTrace();
            return;
        }
        List<String> tokens = redisUtil.getListKey(removeTokenPrefix);
        for(String token : tokens){
            if(token.equals(saveToken))continue;
            String info = token.substring(ch,token.indexOf('.',ch));
            info = Base64.decodeStr(info);
            JSONObject jsonObject = JSONObject.parseObject(info);
            if(username.equals(jsonObject.get("user"))){
                redisUtil.del(token);
            }
        }
    }

    @Async
    public void removeUser(String username){
        if(username==null)return;
        List<String> tokens = redisUtil.getListKey(removeTokenPrefix);
        final int ch = removeTokenPrefix.length()+1;
        for(String token : tokens){
            String info = token.substring(ch,token.indexOf('.',ch));
            info = Base64.decodeStr(info);
            JSONObject jsonObject = JSONObject.parseObject(info);
            if(username.equals(jsonObject.get("user"))){
                redisUtil.del(token);
            }
        }
    }
}
