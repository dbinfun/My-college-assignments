package cn.ourweb.java.test;

import cn.ourweb.java.modules.system.dto.PermissionDto;
import cn.ourweb.java.modules.system.mapper.RoleMapper;
import cn.ourweb.java.modules.system.service.PermissionService;
import cn.ourweb.java.modules.system.service.RoleService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;


@SpringBootTest
public class AppTest {
    @Resource
    private RoleService roleService;
    @Autowired
    private PermissionService permissionService;
    @Test
    public void test(){
        System.out.println(roleService.findByRoleId(0L));
    }
}
