/*
 Navicat Premium Data Transfer

 Source Server         : 本机Mysql
 Source Server Type    : MySQL
 Source Server Version : 80030 (8.0.30)
 Source Host           : localhost:3306
 Source Schema         : javaweb

 Target Server Type    : MySQL
 Target Server Version : 80030 (8.0.30)
 File Encoding         : 65001

 Date: 30/03/2023 21:50:38
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sys_course
-- ----------------------------
DROP TABLE IF EXISTS `sys_course`;
CREATE TABLE `sys_course`  (
  `course_id` bigint NOT NULL AUTO_INCREMENT COMMENT '课程id主键',
  `course_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '课程名称',
  `course_descript` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '课程描述',
  `user_id` bigint NOT NULL COMMENT '老师id',
  PRIMARY KEY (`course_id`) USING BTREE,
  INDEX `course_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `course_id` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_course
-- ----------------------------
INSERT INTO `sys_course` VALUES (6, '数学课', '有趣的数学课', 9);
INSERT INTO `sys_course` VALUES (7, '英语课', '英语', 16);
INSERT INTO `sys_course` VALUES (8, '测试课', '', 15);
INSERT INTO `sys_course` VALUES (9, '物理课', '有趣的物理课', 9);
INSERT INTO `sys_course` VALUES (10, 'java', 'java....', 21);

-- ----------------------------
-- Table structure for sys_homework
-- ----------------------------
DROP TABLE IF EXISTS `sys_homework`;
CREATE TABLE `sys_homework`  (
  `homework_id` bigint NOT NULL AUTO_INCREMENT COMMENT '作业id',
  `course_id` bigint NOT NULL COMMENT '课程id',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `end_time` datetime NULL DEFAULT NULL COMMENT '截至时间',
  `user_id` bigint NOT NULL COMMENT '发布人id',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '作业内容',
  PRIMARY KEY (`homework_id`, `course_id`) USING BTREE,
  INDEX `homework_courseId`(`course_id` ASC) USING BTREE,
  INDEX `homework_id`(`homework_id` ASC) USING BTREE,
  INDEX `homework_userId`(`user_id` ASC) USING BTREE,
  CONSTRAINT `homework_courseId` FOREIGN KEY (`course_id`) REFERENCES `sys_course` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `homework_userId` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_homework
-- ----------------------------
INSERT INTO `sys_homework` VALUES (3, 6, '2022-12-15 13:19:18', '2022-12-01 00:00:00', 9, 'dididi');
INSERT INTO `sys_homework` VALUES (4, 6, '2022-12-15 13:19:29', '2022-12-23 00:00:00', 9, '第二次作业');
INSERT INTO `sys_homework` VALUES (5, 7, '2022-12-17 16:40:41', '2022-12-16 00:00:00', 16, '英语1');
INSERT INTO `sys_homework` VALUES (6, 7, '2022-12-17 16:40:50', '2022-12-18 00:00:00', 16, '英语2');
INSERT INTO `sys_homework` VALUES (7, 9, '2022-12-22 10:49:53', '2022-12-21 00:00:00', 9, '第一次作业');
INSERT INTO `sys_homework` VALUES (8, 9, '2022-12-22 10:50:05', '2022-12-30 00:00:00', 9, '第二次作业');
INSERT INTO `sys_homework` VALUES (9, 10, '2022-12-23 08:50:47', '2022-12-22 00:00:00', 21, 'java1cccc');
INSERT INTO `sys_homework` VALUES (10, 10, '2022-12-23 08:50:42', '2022-12-26 00:00:00', 21, 'java2');

-- ----------------------------
-- Table structure for sys_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_log`;
CREATE TABLE `sys_log`  (
  `log_id` int NOT NULL AUTO_INCREMENT COMMENT '日志id',
  `type` tinyint NOT NULL DEFAULT 0 COMMENT '正常0,异常1',
  `user_id` bigint NULL DEFAULT NULL COMMENT '用户id',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '用户名',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '描述',
  `browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '浏览器',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'ip',
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '方法',
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '参数',
  `exception` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '异常信息',
  `request_time` datetime NULL DEFAULT NULL COMMENT '请求时间',
  `elapsed_time` bigint NULL DEFAULT NULL COMMENT '处理时间',
  PRIMARY KEY (`log_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 928 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_log
-- ----------------------------
INSERT INTO `sys_log` VALUES (902, 0, 1, 'admin', '用户登录', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.54', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.security.rest.AuthController.login()', '{\"username\":\"admin\"}', NULL, '2022-12-23 08:47:11', 658);
INSERT INTO `sys_log` VALUES (903, 0, 1, 'admin', '添加用户', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.54', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.UserController.save()', '{\"admin\":false,\"enabled\":true,\"id\":21,\"nickName\":\"java老师\",\"password\":\"$2a$10$X40kEoIfdmftlGj0SJAKhOF2HlNQbm7XKXanSfx/ukNxgKzJskVMu\",\"roleId\":2,\"username\":\"javaT\"}', NULL, '2022-12-23 08:48:25', 66);
INSERT INTO `sys_log` VALUES (904, 1, NULL, NULL, '添加课程', NULL, NULL, 'cn.ourweb.java.modules.system.rest.CourseControllerT.save()', '{\"courseDescription\":\"java....\",\"courseName\":\"java\"}', '未指定老师', '2022-12-23 08:49:09', 0);
INSERT INTO `sys_log` VALUES (905, 0, 1, 'admin', '添加课程', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.54', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.CourseControllerT.save()', '{\"courseDescription\":\"java....\",\"courseId\":10,\"courseName\":\"java\",\"userId\":21}', NULL, '2022-12-23 08:49:16', 3);
INSERT INTO `sys_log` VALUES (906, 0, 1, 'admin', '添加课程', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.54', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.CourseControllerT.save()', '{\"courseDescription\":\"java....\",\"courseId\":10,\"courseName\":\"java\",\"userId\":9}', NULL, '2022-12-23 08:49:27', 6);
INSERT INTO `sys_log` VALUES (907, 0, 1, 'admin', '添加课程', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.54', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.CourseControllerT.save()', '{\"courseDescription\":\"java....\",\"courseId\":10,\"courseName\":\"java\",\"userId\":21}', NULL, '2022-12-23 08:49:32', 2);
INSERT INTO `sys_log` VALUES (908, 0, 1, 'admin', '为课程分配学生', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.54', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.UserController.updateCourseUsers()', '', NULL, '2022-12-23 08:49:42', 13);
INSERT INTO `sys_log` VALUES (909, 0, 21, 'javaT', '用户登录', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.security.rest.AuthController.login()', '{\"username\":\"javaT\"}', NULL, '2022-12-23 08:50:00', 73);
INSERT INTO `sys_log` VALUES (910, 0, 21, 'javaT', '为课程分配学生', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.UserController.updateCourseUsers()', '', NULL, '2022-12-23 08:50:13', 6);
INSERT INTO `sys_log` VALUES (911, 0, 21, 'javaT', '为课程分配学生', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.UserController.updateCourseUsers()', '', NULL, '2022-12-23 08:50:18', 6);
INSERT INTO `sys_log` VALUES (912, 0, 21, 'javaT', '发布任务', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.HomeworkController.addHomework()', '{\"content\":\"java1\",\"courseId\":10,\"createTime\":\"2022-12-23T08:50:33.015+08:00\",\"endTime\":1671638400000,\"id\":9,\"userId\":21}', NULL, '2022-12-23 08:50:33', 4);
INSERT INTO `sys_log` VALUES (913, 0, 21, 'javaT', '发布任务', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.HomeworkController.addHomework()', '{\"content\":\"java2\",\"courseId\":10,\"createTime\":\"2022-12-23T08:50:42.158+08:00\",\"endTime\":1671984000000,\"id\":10,\"userId\":21}', NULL, '2022-12-23 08:50:42', 4);
INSERT INTO `sys_log` VALUES (914, 0, 21, 'javaT', '发布任务', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.HomeworkController.addHomework()', '{\"content\":\"java1cccc\",\"courseId\":10,\"createTime\":\"2022-12-23T08:50:47.284+08:00\",\"endTime\":1671638400000,\"id\":9,\"userId\":21}', NULL, '2022-12-23 08:50:47', 6);
INSERT INTO `sys_log` VALUES (915, 0, 10, 'stu1', '用户登录', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0', '127.0.0.1', 'cn.ourweb.java.modules.security.rest.AuthController.login()', '{\"username\":\"stu1\"}', NULL, '2022-12-23 08:51:10', 68);
INSERT INTO `sys_log` VALUES (916, 1, NULL, NULL, '提交作业', NULL, NULL, 'cn.ourweb.java.modules.system.rest.UserHomeworkController.add()', '{\"content\":\"fasdfasdf\",\"homeworkId\":9,\"opinion\":\"\"}', '作业提交已经截至', '2022-12-23 08:51:22', 2);
INSERT INTO `sys_log` VALUES (917, 0, 10, 'stu1', '上传文件', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0', '127.0.0.1', 'cn.ourweb.java.modules.system.rest.FileController.uploadFile()', '{\"userId\":1}', NULL, '2022-12-23 08:51:41', 4);
INSERT INTO `sys_log` VALUES (918, 0, 10, 'stu1', '提交作业', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0', '127.0.0.1', 'cn.ourweb.java.modules.system.rest.UserHomeworkController.add()', '{\"annex\":\"/file/20221223/10/1/1671756701148.t.txt\",\"content\":\"这是答案\",\"homeworkId\":10,\"isP\":false,\"opinion\":\"\",\"updateTime\":\"2022-12-23T08:51:43.14+08:00\",\"userId\":10}', NULL, '2022-12-23 08:51:43', 5);
INSERT INTO `sys_log` VALUES (919, 0, 21, 'javaT', '批改作业', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.UserHomeworkController.correcting()', '[{\"homeworkId\":10},{\"userId\":10},{\"fraction\":95},{\"opinion\":\"还不错\"}]', NULL, '2022-12-23 08:52:29', 9);
INSERT INTO `sys_log` VALUES (920, 0, 10, 'stu1', '登出', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0', '127.0.0.1', 'cn.ourweb.java.modules.security.rest.AuthController.logout()', '', NULL, '2022-12-23 08:52:43', 0);
INSERT INTO `sys_log` VALUES (921, 0, 11, 'stu2', '用户登录', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0', '127.0.0.1', 'cn.ourweb.java.modules.security.rest.AuthController.login()', '{\"username\":\"stu2\"}', NULL, '2022-12-23 08:52:48', 67);
INSERT INTO `sys_log` VALUES (922, 0, 21, 'javaT', '为课程分配学生', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.UserController.updateCourseUsers()', '', NULL, '2022-12-23 08:53:05', 6);
INSERT INTO `sys_log` VALUES (923, 0, 11, 'stu2', '上传文件', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0', '127.0.0.1', 'cn.ourweb.java.modules.system.rest.FileController.uploadFile()', '{\"userId\":1}', NULL, '2022-12-23 08:53:25', 2);
INSERT INTO `sys_log` VALUES (924, 0, 11, 'stu2', '提交作业', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0', '127.0.0.1', 'cn.ourweb.java.modules.system.rest.UserHomeworkController.add()', '{\"annex\":\"/file/20221223/11/1/1671756805274.新建 文本文档 (2).txt\",\"content\":\"fffffff\",\"homeworkId\":10,\"isP\":false,\"opinion\":\"\",\"updateTime\":\"2022-12-23T08:53:26.771+08:00\",\"userId\":11}', NULL, '2022-12-23 08:53:27', 4);
INSERT INTO `sys_log` VALUES (925, 0, 21, 'javaT', '批改作业', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.UserHomeworkController.correcting()', '[{\"homeworkId\":10},{\"userId\":11},{\"fraction\":100},{\"opinion\":\"fffff\"}]', NULL, '2022-12-23 08:53:45', 4);
INSERT INTO `sys_log` VALUES (926, 0, 21, 'javaT', '导出作业情况', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.system.rest.UserHomeworkController.downloadExcel()', '{\"homeworkId\":10}', NULL, '2022-12-23 08:53:52', 438);
INSERT INTO `sys_log` VALUES (927, 0, 21, 'javaT', '修改头像', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '0:0:0:0:0:0:0:1', 'cn.ourweb.java.modules.security.rest.AuthController.avatar()', '', NULL, '2022-12-23 08:54:35', 3);

-- ----------------------------
-- Table structure for sys_permission
-- ----------------------------
DROP TABLE IF EXISTS `sys_permission`;
CREATE TABLE `sys_permission`  (
  `permission_id` bigint NOT NULL AUTO_INCREMENT COMMENT '权限id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '权限名称',
  `permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '权限标识',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '权限描述',
  `router` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '菜单路由',
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '菜单图标',
  `pid` bigint NULL DEFAULT NULL COMMENT '上级菜单',
  PRIMARY KEY (`permission_id`) USING BTREE,
  INDEX `pid`(`pid` ASC) USING BTREE,
  CONSTRAINT `my_pid_id` FOREIGN KEY (`pid`) REFERENCES `sys_permission` (`permission_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_permission
-- ----------------------------
INSERT INTO `sys_permission` VALUES (1, '系统管理', NULL, NULL, NULL, 'el-icon-user', NULL);
INSERT INTO `sys_permission` VALUES (2, '课程管理', NULL, NULL, NULL, 'el-icon-s-platform\r\n', NULL);
INSERT INTO `sys_permission` VALUES (3, '课程和作业', NULL, NULL, NULL, 'el-icon-s-flag', NULL);
INSERT INTO `sys_permission` VALUES (4, '日志管理', NULL, NULL, '/home/log', 'el-icon-reading', 1);
INSERT INTO `sys_permission` VALUES (5, '课程分配', NULL, NULL, '/home/course', 'el-icon-s-custom', 1);
INSERT INTO `sys_permission` VALUES (6, '我教的课程', NULL, NULL, '/home/myteachcourse', 'el-icon-data-analysis', 2);
INSERT INTO `sys_permission` VALUES (7, '我的课程', NULL, NULL, '/home/mycourse', 'el-icon-data-analysis', 3);
INSERT INTO `sys_permission` VALUES (8, '用户管理', NULL, NULL, '/home/usermanage', 'el-icon-data-analysis', 1);

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `role_id` bigint NOT NULL COMMENT '权限主键id',
  `role_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'role名称',
  `role_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'role描述',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (1, 'admin', '管理员');
INSERT INTO `sys_role` VALUES (2, 'teacher', '老师');
INSERT INTO `sys_role` VALUES (3, 'student', '学生');

-- ----------------------------
-- Table structure for sys_role_permission
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_permission`;
CREATE TABLE `sys_role_permission`  (
  `role_id` bigint NOT NULL COMMENT '角色id',
  `permission_id` bigint NOT NULL COMMENT '权限id',
  PRIMARY KEY (`role_id`, `permission_id`) USING BTREE,
  INDEX `role_permission_peid`(`permission_id` ASC) USING BTREE,
  CONSTRAINT `role_permission_peid` FOREIGN KEY (`permission_id`) REFERENCES `sys_permission` (`permission_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `role_permission_roid` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role_permission
-- ----------------------------
INSERT INTO `sys_role_permission` VALUES (1, 1);
INSERT INTO `sys_role_permission` VALUES (1, 2);
INSERT INTO `sys_role_permission` VALUES (2, 2);
INSERT INTO `sys_role_permission` VALUES (1, 3);
INSERT INTO `sys_role_permission` VALUES (3, 3);
INSERT INTO `sys_role_permission` VALUES (1, 4);
INSERT INTO `sys_role_permission` VALUES (1, 5);
INSERT INTO `sys_role_permission` VALUES (1, 6);
INSERT INTO `sys_role_permission` VALUES (2, 6);
INSERT INTO `sys_role_permission` VALUES (1, 7);
INSERT INTO `sys_role_permission` VALUES (3, 7);
INSERT INTO `sys_role_permission` VALUES (1, 8);

-- ----------------------------
-- Table structure for sys_tmp_permission
-- ----------------------------
DROP TABLE IF EXISTS `sys_tmp_permission`;
CREATE TABLE `sys_tmp_permission`  (
  `user_id` bigint NOT NULL COMMENT '用户id',
  `permission_id` bigint NOT NULL COMMENT '权限',
  `course` bigint NOT NULL COMMENT '课程号',
  `origin_user_id` bigint NOT NULL COMMENT '原用户id',
  PRIMARY KEY (`user_id`, `permission_id`, `course`, `origin_user_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_tmp_permission
-- ----------------------------

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `user_id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户主键',
  `username` varchar(63) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名,可以是学号,',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码',
  `nick_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '昵称',
  `is_admin` tinyint(1) UNSIGNED ZEROFILL NOT NULL DEFAULT 0 COMMENT '是否为管理',
  `enabled` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否启用',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '头像',
  `realname` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '真实姓名',
  `phone` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '手机号',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱',
  `role_id` bigint NULL DEFAULT NULL COMMENT '权限,由于角色单一,所以只靠路一个用户一个角色',
  PRIMARY KEY (`user_id`) USING BTREE,
  UNIQUE INDEX `sys_user_username`(`username` ASC) USING BTREE COMMENT '用户名唯一',
  INDEX `ro_id`(`role_id` ASC) USING BTREE,
  CONSTRAINT `ro_id` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`role_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 'admin', '$2a$10$mQ/RJqJetxJ5uh0m1V6ch.tWQ79OOO4yMU77MqZEeQiFnRjaosUKe', '管理员', 1, 1, '/avatar/20221127/1/1669478899892.jpeg', NULL, NULL, NULL, NULL);
INSERT INTO `sys_user` VALUES (9, 'sxT', '$2a$10$RtZ/5vS4DEuvQIz6IUlq2.Svh8FZq59ZKkOanDWOaV4OKPJNeDz8e', '数学老师', 0, 1, '/avatar/20221222/9/1671677648546.png', NULL, NULL, NULL, 2);
INSERT INTO `sys_user` VALUES (10, 'stu1', '$2a$10$xUQ6OKqj44oRc5gpRT3imehV1SFOPouOmrR7Sv8OhhLD2v2NDMNHC', '学1', 0, 1, '', NULL, NULL, NULL, 3);
INSERT INTO `sys_user` VALUES (11, 'stu2', '$2a$10$57Sf1Wk8jRNsjMMDSxq0jOM7sDZ6YjYauJzE3U6XVaXQFBwe9O5zO', '学2', 0, 1, NULL, NULL, NULL, NULL, 3);
INSERT INTO `sys_user` VALUES (12, 'stu3', '$2a$10$c3Qdz/XOMatvncVjEdX7VOjUSQ2IFZbgDDKtd.Mug1sFP8WnANVhi', '学生3', 0, 1, NULL, NULL, NULL, NULL, 3);
INSERT INTO `sys_user` VALUES (15, 'ywT', '$2a$10$.86KHEhrh9DWi5Wy3mKSj.nnirEUzMNKRzhFXjtU8tNMJttG/jKCW', '语文老师', 0, 1, NULL, NULL, NULL, NULL, 2);
INSERT INTO `sys_user` VALUES (16, 'yyT', '$2a$10$E3iR74hQyKMD7bWc2nZfwO96bxHXWfJ5DboF3QwO2mJ3M86/M0uqu', '英语老师', 0, 1, '/avatar/20221217/16/1671267957101.png', NULL, NULL, NULL, 2);
INSERT INTO `sys_user` VALUES (17, 'stu4', '$2a$10$M3I.4zA.NxrbelcEkDUmTu6nOK2IOvcrha2s0tJ3vF6LfaRp./yQy', '学生4', 0, 1, NULL, NULL, NULL, NULL, 3);
INSERT INTO `sys_user` VALUES (18, 'stu5', '$2a$10$w74xuBPHles5CQR95b.yqOlYpeOK9/3KiIxGsG/koEQHGHsSiOSBa', '学生5', 0, 1, NULL, NULL, NULL, NULL, 3);
INSERT INTO `sys_user` VALUES (19, 'stu6', '$2a$10$j5Fzvv.ASUgNGpMId5HZ9OuPM2fb8pxB/G5lDTwOBTQyiyjzOrS02', '学生6', 0, 1, NULL, NULL, NULL, NULL, 3);
INSERT INTO `sys_user` VALUES (20, 'stu7', '$2a$10$X1poO0TydVZAi25RC99GcuQDaXDr9lH72of16v29SHHB7iljhWlNu', '学生7', 0, 1, NULL, NULL, NULL, NULL, 3);
INSERT INTO `sys_user` VALUES (21, 'javaT', '$2a$10$X40kEoIfdmftlGj0SJAKhOF2HlNQbm7XKXanSfx/ukNxgKzJskVMu', 'java老师', 0, 1, '/avatar/20221223/21/1671756874592.jpeg', NULL, NULL, NULL, 2);

-- ----------------------------
-- Table structure for sys_user_course
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_course`;
CREATE TABLE `sys_user_course`  (
  `user_id` bigint NOT NULL COMMENT '用户id',
  `course_id` bigint NOT NULL COMMENT '课程id',
  PRIMARY KEY (`user_id`, `course_id`) USING BTREE,
  INDEX `user_course`(`course_id` ASC) USING BTREE,
  CONSTRAINT `user_course` FOREIGN KEY (`course_id`) REFERENCES `sys_course` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user_course
-- ----------------------------
INSERT INTO `sys_user_course` VALUES (10, 6);
INSERT INTO `sys_user_course` VALUES (11, 6);
INSERT INTO `sys_user_course` VALUES (10, 7);
INSERT INTO `sys_user_course` VALUES (11, 7);
INSERT INTO `sys_user_course` VALUES (12, 7);
INSERT INTO `sys_user_course` VALUES (17, 7);
INSERT INTO `sys_user_course` VALUES (11, 9);
INSERT INTO `sys_user_course` VALUES (12, 9);
INSERT INTO `sys_user_course` VALUES (17, 9);
INSERT INTO `sys_user_course` VALUES (18, 9);
INSERT INTO `sys_user_course` VALUES (19, 9);
INSERT INTO `sys_user_course` VALUES (20, 9);
INSERT INTO `sys_user_course` VALUES (10, 10);
INSERT INTO `sys_user_course` VALUES (11, 10);
INSERT INTO `sys_user_course` VALUES (12, 10);
INSERT INTO `sys_user_course` VALUES (17, 10);
INSERT INTO `sys_user_course` VALUES (18, 10);
INSERT INTO `sys_user_course` VALUES (19, 10);
INSERT INTO `sys_user_course` VALUES (20, 10);

-- ----------------------------
-- Table structure for sys_user_homework
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_homework`;
CREATE TABLE `sys_user_homework`  (
  `user_id` bigint NOT NULL COMMENT '用户id',
  `homework_id` bigint NOT NULL COMMENT '作业表',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '提交的内容',
  `annex` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '附件url',
  `opinion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '批改意见',
  `fraction` tinyint NULL DEFAULT NULL COMMENT '分数(0-100,初始为-1,表示未批改)',
  `update_time` datetime NULL DEFAULT NULL COMMENT '时间',
  `is_p` int NULL DEFAULT 0 COMMENT '是否批改',
  PRIMARY KEY (`user_id`, `homework_id`) USING BTREE,
  INDEX `user_h_homeworkId`(`homework_id` ASC) USING BTREE,
  CONSTRAINT `user_h_homeworkId` FOREIGN KEY (`homework_id`) REFERENCES `sys_homework` (`homework_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_h_userid` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user_homework
-- ----------------------------
INSERT INTO `sys_user_homework` VALUES (10, 4, '发撒打发士大夫', '/file/20221215/10/1/1671084324199.6030ce9fe7bce719f42e2b35.jpg', '不错', 89, '2022-12-08 13:21:38', 1);
INSERT INTO `sys_user_homework` VALUES (10, 6, '就这就这？阿斯顿发生发射点发射点f发射点发发送蒂法fsadfasdf fasd fasdfsdfsda ', '/file/20221217/10/1/1671267111093.2020121071-邓彬-的二次web作业.docx', '不错', 81, '2022-12-17 17:00:40', 1);
INSERT INTO `sys_user_homework` VALUES (10, 10, '这是答案', '/file/20221223/10/1/1671756701148.t.txt', '还不错', 95, '2022-12-23 08:51:43', 1);
INSERT INTO `sys_user_homework` VALUES (11, 4, 'stu2', '/file/20221216/11/1/1671167831895.7e19dbfa880511ebb6edd017c2d2eca2.jpg', '还行', 83, '2022-12-17 13:21:45', 0);
INSERT INTO `sys_user_homework` VALUES (11, 6, '您好阿伟', '/file/20221217/11/1/1671267786732.image.png', '广发发生的发射点发按时打发范德萨分', 86, '2022-12-17 17:03:16', 1);
INSERT INTO `sys_user_homework` VALUES (11, 8, 'stu1的作业答案', '/file/20221222/11/1/1671677508926.新建 文本文档 (2).txt', '还不错', 83, '2022-12-22 10:51:51', 1);
INSERT INTO `sys_user_homework` VALUES (11, 10, 'fffffff', '/file/20221223/11/1/1671756805274.新建 文本文档 (2).txt', 'fffff', 100, '2022-12-23 08:53:27', 1);
INSERT INTO `sys_user_homework` VALUES (12, 8, 'stu3的作业', '/file/20221222/12/1/1671677550152.t.txt', '还不错11111', 58, '2022-12-22 10:52:32', 1);

SET FOREIGN_KEY_CHECKS = 1;
