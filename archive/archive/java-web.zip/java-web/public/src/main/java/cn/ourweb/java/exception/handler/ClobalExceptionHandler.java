package cn.ourweb.java.exception.handler;

import cn.ourweb.java.base.Result;
import cn.ourweb.java.exception.BadRequestException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
public class ClobalExceptionHandler {
    @ExceptionHandler(Throwable.class)
    public Result handleException(Throwable e){
        log.error(e.getMessage(),e);
        return Result.error("未知错误");
    }
    @ExceptionHandler(BadCredentialsException.class)
    public Result handleBadCredentialsException(BadCredentialsException e){
        log.error(e.getMessage(),e);
        return Result.error("认证失败");
    }
    @ExceptionHandler(AccessDeniedException.class)
    public Result handleAccessDeniedException(AccessDeniedException e){
        log.error(e.getMessage(),e);
        return Result.error("无权访问");
    }
    @ExceptionHandler(BadRequestException.class)
    public Result handleBadRequestException(BadRequestException e){
        log.error(e.getMessage(),e);
        return Result.error(e.getMessage());
    }
}
