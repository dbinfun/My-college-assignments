package cn.ourweb.java.base;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.http.HttpStatus;
import java.io.Serializable;
import java.util.Date;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Result implements Serializable {
    private Integer code;
    private String message;
    private Date timestamp;
    private Object data;
    private Result(HttpStatus httpStatus){
        this.code = httpStatus.value();
        this.timestamp = new Date();
    }
    public static Result ok(){
        return new Result(HttpStatus.OK);
    }

    public static Result ok(String message){
        Result result = new Result(HttpStatus.OK);
        result.message = message;
        return result;
    }

    public static Result ok(Object data){
        Result result = new Result(HttpStatus.OK);
        result.data = data;
        return result;
    }
    public static Result error(){
        return new Result(HttpStatus.BAD_REQUEST);
    }

    public static Result error(String message){
        Result result = new Result(HttpStatus.BAD_REQUEST);
        result.message = message;
        return result;
    }
}
