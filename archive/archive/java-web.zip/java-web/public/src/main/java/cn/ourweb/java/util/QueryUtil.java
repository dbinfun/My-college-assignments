package cn.ourweb.java.util;

import cn.hutool.core.util.StrUtil;
import cn.ourweb.java.annotation.Query;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
public class QueryUtil {
    public static <R,Q>QueryWrapper<R> wrapper(Class<R> root,Q query){
        QueryWrapper<R> queryWrapper = new QueryWrapper<>();
        try{
            List<Field> fieldList =  getAllFields(query.getClass(),new ArrayList<>());
            for(Field field : fieldList){
                field.setAccessible(true);
                Query q = field.getAnnotation(Query.class);
                Object value = field.get(query);
                if(value==null)continue;
                if(q!=null){
                    String name = q.columnName();
                    //获取字段名
                    String attributeName = StrUtil.isBlank(name)?getColumnName(root,field.getName()):name;
                    if(StrUtil.isBlank(attributeName))continue;
                    switch (q.type()){
                        case GREATER_THAN:
                            queryWrapper.ge(attributeName,value);
                            break;
                        case LESS_THAN:
                            queryWrapper.le(attributeName,value);
                            break;
                        case LESS_THAN_NQ:
                            queryWrapper.lt(attributeName,value);
                            break;
                        case GREATER_THAN_NQ:
                            queryWrapper.gt(attributeName,value);
                            break;
                        case INNER_LIKE:
                            queryWrapper.like(attributeName,value);
                            break;
                        case LEFT_LIKE:
                            queryWrapper.likeLeft(attributeName,value);
                            break;
                        case RIGHT_LIKE:
                            queryWrapper.likeRight(attributeName,value);
                            break;
                        case IN:
                            if(value instanceof Collection&&((Collection<?>)value).size()>0) {
                                Object[] t = ((Collection<?>) value).toArray();
                                queryWrapper.in(attributeName, t);
                            }
                            break;
                        case NOT_IN:
                            if(value instanceof Collection&&((Collection<?>)value).size()>0) {
                                Object[] t = ((Collection<?>) value).toArray();
                                queryWrapper.notIn(attributeName, t);
                            }
                            break;
                        case NOT_EQUAL:
                            queryWrapper.ne(attributeName,value);
                            break;
                        case BETWEEN:
                            if (value instanceof Collection) {
                                Object[] t = ((Collection<?>)value).toArray();
                                if(t.length<2)break;
                                queryWrapper.between(attributeName,t[0],t[1]);
                            }
                            break;
                        case NOT_NULL:
                            queryWrapper.isNotNull(attributeName);
                            break;
                        case IS_NULL:
                            queryWrapper.isNull(attributeName);
                            break;
                        default:
                            queryWrapper.eq(attributeName,value);
                            break;
                    }
                }
            }
        }catch (Exception e){

        }
        return queryWrapper;
    }

    public static List<Field> getAllFields(Class clazz, List<Field> fields) {
        if (clazz != null) {
            fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
            getAllFields(clazz.getSuperclass(), fields);
        }
        return fields;
    }
    public static String getColumnName(Class clazz, String filedName) {
        if(filedName==null)return "";
        try {
            Field column = clazz.getDeclaredField(filedName);
            TableId tableId = column.getAnnotation(TableId.class);//获取主键名
            if(tableId!=null){
                return StrUtil.isBlank(tableId.value())?filedName:tableId.value();
            }
            TableField tableField = column.getAnnotation(TableField.class);//获取普通字段名
            if(tableField!=null){
                //非数据库字段直接返回空串
                if(!tableField.exist()){
                    return "";
                }
                return StrUtil.isBlank(tableField.value())?filedName:tableField.value();
            }
            return filedName;//都没有直接返回属性名
        } catch (NoSuchFieldException e) {
            return "";
        }
    }
}
