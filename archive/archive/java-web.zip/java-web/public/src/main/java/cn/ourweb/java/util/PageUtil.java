package cn.ourweb.java.util;

import java.util.List;

public class PageUtil {
    public static final List toPage(int page, int size, List list){
        return null;
    }
}
