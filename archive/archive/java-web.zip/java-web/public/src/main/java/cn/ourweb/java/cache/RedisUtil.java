package cn.ourweb.java.cache;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@Component
public class RedisUtil {
    private final RedisTemplate<String, Object> redisTemplate;
    @Autowired
    public RedisUtil(RedisTemplate redisTemplate) {
        if(redisTemplate==null){
            log.error("===redis 连接失败===");
        }
        if(redisTemplate!=null) {
            redisTemplate.setKeySerializer(new StringRedisSerializer());//采用string序列化方式,去掉多余的\
        }
        this.redisTemplate = redisTemplate;
    }

    /**
     * 获取缓存
     * @param key key
     * @return value
     */
    public Object get(String key){
        return key==null?null:redisTemplate.opsForValue().get(key);
    }

    /**
     * 放入缓存
     * @param key key
     * @param value value
     * @return true/false 成功/失败
     */
    public boolean set(String key, Object value) {
        try {
            redisTemplate.opsForValue().set(key, value);
            return true;
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            return false;
        }
    }

    /**
     * 放入缓存设置时间
     * @param key
     * @param value
     * @param time
     * @return
     */
    public boolean set(String key, Object value, long time,TimeUnit timeUnit) {
        try {
            if (time > 0) {
                redisTemplate.opsForValue().set(key, value, time,timeUnit);
            } else {
                set(key, value);
            }
            return true;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return false;
        }
    }

    /**
     * 过期时间
     * @param key key
     * @return 0/others 0不存在或已过期。
     */
    public long getExpire(String key) {
        Long time =  redisTemplate.getExpire(key, TimeUnit.SECONDS);
        return time==null?0L:time;
    }

    /**
     * 是否存在key对应的值
     * @param key key
     * @return true/false
     */
    public boolean hasKey(String key) {
        Boolean has = redisTemplate.hasKey(key);
        return has != null && has;
    }

    /**
     * 指定过期时间
     * @param key key
     * @param time time
     * @param timeUnit timeUnit
     * @return 成功否
     */
    public boolean expire(String key, long time, TimeUnit timeUnit) {
        try {
            if (time > 0) {
                redisTemplate.expire(key, time, timeUnit);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return false;
        }
        return true;
    }

    /**
     * 根据前缀获取key
     * @param prefix 前缀
     * @return
     */
    public List<String> getListKey(String prefix) {
        List<String> keys = redisTemplate.keys(prefix.concat("*")).stream().map(Objects::toString).collect(Collectors.toList());
        return keys;
    }

    /**
     * 删除缓存
     * @param keys
     */
    public void del(String... keys) {
        if (keys != null && keys.length > 0) {
            final List<String> list = Arrays.stream(keys).filter(Objects::nonNull).collect(Collectors.toList());
            redisTemplate.delete(list);
        }
    }

}

