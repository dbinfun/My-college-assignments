// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import Element from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import Axios from 'axios'
//Axios.defaults.baseURL='/'
Axios.defaults.baseURL='http://localhost:8080'
//Axios.defaults.baseURL='http://192.168.31.213:10393/mock/0efb2159-b7ad-4c9d-a03c-dfb42fd35aba'
Vue.prototype.$axios = Axios
Vue.use(router);
Vue.use(Element);

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
