<template>
  <div id="home">
    <div id="menu">
      <el-menu
           background-color="#545c64"
           text-color="#fff"
           active-text-color="#ffd04b"
           router
           style="height: 100%;"
        >
          <template>
            <el-menu-item style=""
                          :key="0" :index="'/home/'"
                         >

              <span slot="title" style="text-align: center;">首页</span>
            </el-menu-item>
          </template>
          <NavMenu :navMenus="menuData" style="width: 100%;height: 100%;margin-left: 8px;"></NavMenu>
      </el-menu>
    </div>
    <div id="content">
      <div id="head">
        <el-row>
          <el-col :span="24"><div class="grid-content bg-purple-dark"><Head :userInfo="userInfo"></Head></div></el-col>
        </el-row>
      </div>
      <div id='test' style="position:absolute; top:50px;width:90%;bottom: 0px ;flex: 1;">
        <router-view class="noscorll" style="height: 100%;width:100%;overflow: auto;"></router-view>
      </div>
    </div>
  </div>
</template>
<script>
import NavMenu from '../components/home/Menu.vue'
import Head from '../components/home/Head.vue'
export default {
  components: {
    NavMenu: NavMenu,
    Head: Head
  },
  watch: {
    '$route' () {
      if(!this.checkLogin(this)){
        return;
      }
      this.createMenu();//我的初始化方法
    }
  },
  beforeRouteEnter:(to,from,next)=>{
    next(vm=>{
      if(!vm.checkLogin(vm)){
        return
      }
      vm.createMenu();
      vm.getUserInfo();
    })
  },
  methods:{
    checkLogin(that){
      var token = localStorage.getItem('token');
      if(token==undefined||token==null) {
        that.$alert('登录信息已经过期', '错误', {
          confirmButtonText: '确定',
          callback: action => {
            that.$message({
              type: 'info',
              message: `请重新登录`
            });
            localStorage.removeItem("token");
            localStorage.removeItem("user");
            that.$router.replace('/');
          }
        });
        return false;
      }
      return true;
    },
    createMenu(){
      const that = this;
      that.$axios({
        method: 'get',
        url: '/auth/myPermission',
        headers: {'token': localStorage.getItem('token')},
        responseType: 'json'
      }).then(function (response) {
          //console.log(response.data);
          that.$set(that,'menuData',response.data);
        })
        .catch(function (error) {
          that.open(that);
        });
    },
    open(that){
      this.$alert('抱歉,您的信息好像有误,或者登录信息已经过期', '错误', {
        confirmButtonText: '确定',
        callback: action => {
          this.$message({
            type: 'info',
            message: `请重新登录`
          });
          localStorage.removeItem("token");
          localStorage.removeItem("user");　
          that.$router.replace('/');
        }
      });
    },
    getUserInfo(){
      var that = this;
      that.$axios({
        method: 'post',
        url: '/auth/info',
        headers: {'token': localStorage.getItem('token')},
        responseType: 'json'
      }).then(function (response) {
        response.data.data.avatar = that.$axios.defaults.baseURL+response.data.data.imageUrl;
        that.$set(that,'userInfo',response.data.data);
        console.log(response.data);

      })
        .catch(function (error) {
          that.$message({
            message: error.response.data.message,
            type: 'error'
          });
        });
    }
  },
  data() {
    return {
      userInfo: {
        avatar: 'https://dummyimage.com/50.png/09f/fff',
        username: "db"
      },
      menuData: [
        {
          //一级
          id: 0,
          router: "/home",
          icon: "el-icon-message",
          name: "一级菜单"
        },
      ]
    };
  }
};
</script>

<style scoped>
  #home{
    width: 100%;
    height: 100%;
    display: flex;
  }
  #menu{
    width: 200px;
    height: 100%;
    overflow: hidden;
    flex-shrink:0;
  }
  #content{
    flex: 1;
    height: 100%;
  }
  #head{
    width: 100%;
    height: 50px;
    /* background-color: rebeccapurple; */
    background-color: rgba(1, 1, 1, 0);
  }
  .el-row {
      margin-bottom: 20px;
      &:last-child {
        margin-bottom: 0;
      }
    }
    .el-col {
      border-radius: 4px;
    }
    .bg-purple-dark {
      background: #99a9bf;
    }
    .noscorll::-webkit-scrollbar{
      display: none;
    }
</style>
