<template>
  <div>
    <el-row :gutter="20" style="margin-top:10px;">
      <el-col :span="8">
        <div class="grid-content bg-purple">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>个人中心</span>
            </div>
            <div class="name-role">

            </div>
            <div class="registe-info">

            </div>
            <el-divider>
              <el-popover
                placement="top-start"
                title="上传头像"
                width="200"
                trigger="hover"
                content="请自己准备方块头像">
                <el-button slot="reference">
                  <el-upload
                    class="avatar-uploader"
                    :action="uri"
                    :show-file-list="false"
                    :headers="header"
                    :on-success="handleAvatarSuccess"
                    :before-upload="beforeAvatarUpload">
                    <img v-if="dataForm.imageUrl" :src="dataForm.imageUrl" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                  </el-upload>
                </el-button>
              </el-popover>
            </el-divider>
            <div class="personal-relation">
              <div class="relation-item"><div style="float: right; padding-right:20px;"></div></div>
            </div>
            <div class="personal-relation">
              <div class="relation-item"><div style="float: right; padding-right:20px;"></div></div>
            </div>
            <div class="personal-relation">
              <div class="relation-item">用户名:<div style="float: right; padding-right:20px;">
                <el-tag>{{dataForm.username}}</el-tag>
              </div></div>
            </div>
            <div class="personal-relation">
              <div class="relation-item">昵称:<div style="float: right; padding-right:20px;">
                <el-tag type="success">{{dataForm.nickName}}</el-tag>
              </div></div>
            </div>
            <div class="personal-relation">
              <div class="relation-item">
                <div style="float: right; padding-right:20px;">
                  <router-link to="/home"><el-button type="success">返回主页</el-button></router-link>
                </div>
                  <el-button type="danger" @click="logout">登出</el-button>
                </div>
            </div>

<!--            <div class="personal-relation">-->
<!--              <div class="relation-item">所属企业:  <div style="float: right; padding-right:20px;">杭州诚聚</div></div>-->
<!--            </div>-->
<!--            <div class="personal-relation">-->
<!--              <div class="relation-item">首页链接:  <div style="float: right; padding-right:20px;"></div></div>-->
<!--            </div>-->
          </el-card>
        </div>
      </el-col>
      <el-col :span="16">
        <div class="grid-content bg-purple">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>修改密码</span>
            </div>
            <div>
              <el-form label-width="80px" size="small" label-position="right" :model="pojo" :rules="LoginFormRules" ref="LoginFormRef">
                <el-form-item label="旧密码" prop="oldPassword">
                  <el-input  auto-complete="off" type="password" placeholder="请输入旧密码" show-password required="true" v-model="pojo.oldPassword"></el-input>
                </el-form-item>
                <el-form-item label="新密码" prop="newPassword1">
                  <el-input  auto-complete="off" type="password" placeholder="请输入密码" show-password required="true"  v-model="pojo.newPassword1"></el-input>
                </el-form-item>
                <el-form-item label="新密码" type="password" prop="newPassword2">
                  <el-input  auto-complete="off" type="password" placeholder="请再次输入密码" show-password required="true" v-model="pojo.newPassword2"></el-input>
                </el-form-item>
              </el-form>
              <div slot="footer" class="dialog-footer">
                <el-button size="mini" type="primary" @click="changePass">提交</el-button>
                <el-button size="mini" type="warning" @click="pojo={}">重置</el-button>
              </div>
            </div>
          </el-card>
        </div>
      </el-col>

    </el-row>

  </div>
</template>

<script>
export default {
  name: "Mine",
  data() {
    return {
      header:{},
      uri: "",
      dataForm:{
        username: 'username',
        nickName: '超级管理员',
        imageUrl: '',
      },
      pojo:{
        oldPassword: "",
        newPassword1: "",
        newPassword2: ""
      },
      LoginFormRules: {
        oldPassword:[
          { required: true, message: '请输入用户名', trigger: 'blur' },
        ],
        newPassword1:[
          { required: true, message: '请输入密码', trigger: 'blur' },
        ],
        newPassword2:[
          { required: true, message: '请输入密码', trigger: 'blur' },
        ]
      }
    };
  },
  created() {
    this.header.token=localStorage.getItem("token");
    this.uri = this.$axios.defaults.baseURL+"/auth/avatar"
    this.initInfo();
  },
  methods: {
    initInfo(){
      var that = this;
      that.$axios({
        method: 'post',
        url: '/auth/info',
        headers: {'token': localStorage.getItem('token')},
        responseType: 'json'
      }).then(function (response) {
        that.$set(that,'dataForm',response.data.data);
        that.dataForm.imageUrl = that.$axios.defaults.baseURL+response.data.data.imageUrl;
      })
        .catch(function (error) {
            that.$message({
              message: error.response.data.message,
              type: 'error'
            });
        });
    },
    handleAvatarSuccess(res, file) {
      this.dataForm.imageUrl = this.$axios.defaults.baseURL+res.data.url;
    },
    beforeAvatarUpload(file) {
      const isJPG = file.type === 'image/jpeg'||file.type==="image/png";
      const isLt2M = file.size / 1024 / 1024 < 10;

      if (!isJPG) {
        this.$message.error('上传头像图片只能是 JPG 格式!');
      }
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 5MB!');
      }
      return isJPG && isLt2M;
    },
    changePass(){
      this.$refs['LoginFormRef'].validate(async (valid)=> {
        if(valid) {
          var that = this;
          if (this.pojo.newPassword1 != this.pojo.newPassword2) {
            that.$message({
              message: "两次输入密码不一致",
              type: 'error'
            });
            return;
          }
          that.$axios({
            method: 'post',
            url: '/auth/changePassword',
            headers: {'token': localStorage.getItem('token')},
            responseType: 'json',
            params: {
              oldPassword: this.encode(that.pojo.oldPassword),
              newPassword: this.encode(that.pojo.newPassword2)
            }
          }).then(function (response) {
            localStorage.removeItem("token");
            localStorage.removeItem("token");
            that.$message({
              message: "成功,请重新登陆",
              type: 'success'
            });
            that.$router.replace("/");
          }).catch(function (error) {
            that.$message({
              message: error.response.data.message,
              type: 'error'
            });
          });
        }else{
          return false;
        }
      })
    },
    encode(password){
      var PUBLIC_KEY = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCqR637Asx/l7Xr/iodfSrMvuoJwwmWsUEHF8RHWhqmg3NuvJZguQPVJCAeekDsq3ZYHM+J8r8XiGBHvRBAHxx+rO9sYilFPd8GGTITwPeCP8vvBctG8panNY5G2/I/AHcoTWjc7gP/nDgiFuTux8+IN/9B455kTNPuhGVG9MmYmQIDAQAB';
      //使用公钥加密
      var encrypt = new JSEncrypt();
      encrypt.setPublicKey('' + PUBLIC_KEY + '');
      var encrypted = encrypt.encrypt(password);
      return encrypted;
    },
    logout() {
      var that = this;
      this.$confirm('退出登录?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        that.$axios({
          method: 'post',
          url: '/auth/logout',
          headers: {'token': localStorage.getItem('token')},
        }).then(function (response) {
        }).catch(function (error) {
        });
        this.$message({
          type: 'success',
          message: '已经登出!',
        });
        //此处发送请求登出.
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        that.$router.replace('/');
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消登出'
        });
      });
    }
  }
}
</script>

<style scoped>
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409EFF;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 100px;
  height: 100px;
  line-height: 100px;
  text-align: center;
}
.avatar {
  width: 100px;
  height: 100px;
  display: block;
}


.text {
  font-size: 14px;
}

.item {
  margin-bottom: 18px;
}

.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}
.clearfix:after {
  clear: both
}

.box-card {
  width: 100%;
}
//文本样式区
  .name-role {
    font-size: 16px;
    padding: 5px;
    text-align:center;
  }
.sender{
  text-align:center;
}
.registe-info{
  text-align: center;
  padding-top:10px;
}
.personal-relation {
  font-size: 16px;
  padding: 0px 5px 15px;
  margin-right: 1px;
  width: 100%
}

.relation-item {
  padding: 12px;

}
.dialog-footer{
  padding-top:10px ;
  padding-left: 10%;
}
.bg-purple-dark {
  background: #99a9bf;
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
</style>
