<template>
  <div class="login_container">
    <div class="login_box">
      <!-- 头像 -->
      <div class="avatar_box" style="position: absolute;">
        <img src="../assets/logo.png" alt="" style="width: 115%;height: 115%;left:-10px;top:-2px;position: absolute;">
      </div>
      <!-- 表单 -->
      <el-form ref="LoginFormRef" :model="loginForm" label-width="0" :rules="LoginFormRules" class="login_form">
        <el-form-item prop="username">
      <!-- 用户名-->
          <el-input v-model="loginForm.username" prefix-icon="el-icon-user"></el-input>
        </el-form-item>
      <!-- 密码-->
        <el-form-item prop="password">
          <el-input v-model="loginForm.password" prefix-icon="el-icon-lock" type="password"></el-input>
        </el-form-item>
        <el-form-item class="btns">
          <el-button type="primary" @click="login">登录</el-button>
          <el-button type="info" @click="resetLoginForm">重置</el-button>
        </el-form-item>
      </el-form>
      <!-- <el-button :plain="true" @click="openError">错误</el-button> -->
    </div>
  </div>
</template>

<script>
  import '../../static/js/jsencrypt.js';
  export default {
    beforeRouteEnter:(to,from,next)=>{
      var token = localStorage.getItem("token");
      if(token!=undefined&&token!=null){
        next(vm=>{
          vm.$router.replace('/home');
        })
      }
      next();
    },
    data() {
      return {
        // 登录的初始化数据：备注默认应该是空
        loginForm:{
          username:'admin',
          password:'123456'
        },
        LoginFormRules:{
          username:[
            { required: true, message: '请输入用户名', trigger: 'blur' },
          ],
          password:[
            { required: true, message: '请输入密码', trigger: 'blur' },
          ]
        }
      }
    },
    methods: {
      encode(password){
        var PUBLIC_KEY = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCqR637Asx/l7Xr/iodfSrMvuoJwwmWsUEHF8RHWhqmg3NuvJZguQPVJCAeekDsq3ZYHM+J8r8XiGBHvRBAHxx+rO9sYilFPd8GGTITwPeCP8vvBctG8panNY5G2/I/AHcoTWjc7gP/nDgiFuTux8+IN/9B455kTNPuhGVG9MmYmQIDAQAB';
        //使用公钥加密
        var encrypt = new JSEncrypt();
        encrypt.setPublicKey('' + PUBLIC_KEY + '');
        var encrypted = encrypt.encrypt(password);
        return encrypted;
      },
      // 清空表单的校验
      resetLoginForm() {
        this.$refs.LoginFormRef.resetFields()
      },
      //登录的方法：登录逻辑写里面
      login() {
        //this.$router.replace('/home')
        //return
        //首先是校验如果正则的校验通过 -->> 执行数据传输
        var that = this;
        this.$refs['LoginFormRef'].validate(async (valid) => {
          if (valid) {

            //简单的在main.js里面配置了一下如下
            //Vue.prototype.$http = axios
            //axios.defaults.baseURL = 'https://localhost:8080/'

            var password = this.encode(this.loginForm.password);
            //执行数据的交互过程 --即对服务端对应接口进行访问
            this.$axios.post('auth/login',{
              password: password,
              username: this.loginForm.username
            })
             .then(function (response) {
                console.log(response);
                var res = response;
                //正常这里是要分情况写： 1.如果成功 登录到首页面 2.如果失败 弹出对应的提示
                  //如果登录成功存储token
                  localStorage.setItem('token',res.data.data.token);
                  localStorage.setItem('user',JSON.stringify(res.data.data.user));
                  console.log(res.data.data.user);
                  that.opensucess("登录成功");
                  that.$router.replace('/home/');
                  //跳到首页面 这里是根据路由跳转
              })
              .catch(function (error) {
                console.log("error");
                that.openError("登录失败:"+error.response.data.message);
              });

          } else {
            return false
          }
        })
      },
      openError(message){
        this.$message.error(message);
      },
      opensucess(message){
        this.$message({
          message: message,
          type: 'success'
        });
      }
    }
  }
</script>

<style scoped>
  .login_container{
    background-color: #2b4b6b;
    height: 100%;
  }

  .login_box{
    width: 450px;
    height: 300px;
    background-color: #fff;
    border-radius: 3px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%)
  }

  .avatar_box{
    width: 130px;
    height: 130px;
    border: 1px solid #eee;
    border-radius: 50%;
    padding: 10px;
    box-shadow: 0 0 10px #ddd;
    position: absolute;
    left:50%;
    transform: translate(-50%,-50%);
    background-color: #fff;
    img{
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background-color: #eee;
    }
  }

  .login_form{
    position: absolute;
    bottom: 0;
    width: 100%;
    padding: 20px;
    box-sizing: border-box;
  }

  .btns{
    display: flex;
    justify-content:flex-end;
  }
</style>>
