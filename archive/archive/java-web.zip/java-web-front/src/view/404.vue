<template>
  <div>
    <el-empty description="页面走丢了">
      <el-button type="success" @click="goHome">回到首页</el-button>
    </el-empty>
  </div>
</template>

<script>
  export default{
    data(){
      return{

      }
    },
    methods:{
      goHome(){
        this.$router.replace('/home/');
      }
    }
  }
</script>

<style>
</style>
