<template>
  <div style="width: 100%;height: 100%;overflow: auto">
    <el-form :inline="true">
      <el-form-item label="课程名">
        <el-input placeholder="课程名" v-model="searchMap.courseName"></el-input>
      </el-form-item>
      <el-button type="primary" @click="fetchData">查询</el-button>
    </el-form>
    <el-table
      :data="tableData"
      border
      style="width: 100%">
      <el-table-column
        prop="courseId"
        label="课程id"
        width="200">
      </el-table-column>
      <el-table-column
        show-overflow-tooltip
        prop="courseName"
        label="课程名"
        width="200">
      </el-table-column>
      <el-table-column
        show-overflow-tooltip
        prop="courseDescription"
        label="课程描述"
        width="200">
      </el-table-column>
      <el-table-column
        label="作业列表"
        width="200">
        <template slot-scope="scope">
          <el-button type="primary" icon="el-icon-edit" @click="coursesWork(scope.row.courseId)" circle></el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      @size-change="fetchData"
      @current-change="fetchData"
      :current-page.sync="currentPage"
      :page-sizes="[10, 20, 30, 40]"
      :page-size="size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total">
    </el-pagination>
    <el-dialog
      title="作业"
      :visible.sync="dailogVisible">
      <el-table
        :data="homeworks"
        style="width: 100%">
        <el-table-column
          show-overflow-tooltip
          prop="content"
          label="内容"
          width="200">
        </el-table-column>
        <el-table-column
          prop="createTime"
          label="开始时间"
          width="180">
        </el-table-column>
        <el-table-column
          label="截至时间">
          <template slot-scope="scope">
            <el-tag v-if="isJZ(scope.row.endTime)" type="danger">已经截至:{{scope.row.endTime}}</el-tag>
            <el-tag v-else >正在进行:{{scope.row.endTime}}</el-tag>
          </template>
        </el-table-column>
        <el-table-column
          label="查看作业"
          width="100">
          <template slot-scope="scope">
            <el-button type="primary" icon="el-icon-edit" @click="tijiao(scope.row)" circle></el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "myCourse",
  created(){
    this.fetchData()
  },
  data(){
    return{
      tableData:[{
        courseId: 1,
        courseName: '测试',
        courseDescription:'课程'
      }],
      searchMap: {
        courseName: null
      },
      currentPage:1,
      size:10,
      total:10,
      dailogVisible: false,
      homeworks:[
        {
          id: 1,
          courseId:1,
          createTime: "2022-12-11 00:00:00",
          endTime: "2022-12-12 00:00:00",
          content: "作业内容ddd"
        }

      ]
    }
  },
  methods:{
    fetchData() {
      var that = this;
      this.$axios(
        {
          method: 'get',
          url: '/api/course/mycourse',
          params:{
            current: this.currentPage,
            size: this.size,
            courseName: this.searchMap.courseName
          },
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }
        //{`/api/user?page=${this.currentPage}&size=${this.size}`}
      ).then(response=>{
        this.tableData=response.data.records;
        this.total=response.data.total;
      }).catch(function (error){
        that.open("错误",error.response.data.message);
      })
    },
    coursesWork(id){
      this.dailogVisible=true;
      var that = this;
      this.$axios(
        {
          method: 'get',
          url: '/api/homework/getStuH',
          params:{
            current: 1,
            size: -1,
            courseId: id
          },
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }
        //{`/api/user?page=${this.currentPage}&size=${this.size}`}
      ).then(response=>{
        this.homeworks = response.data.records;
      }).catch(function (error){
        that.open("错误",error.response.data.message);
      })
    },
    tijiao(row){
      this.$router.replace("/homework/"+row.id+"/"+row.content);
    },
    isJZ(s){
      return new Date().getTime()>new Date(s).getTime();
    }
  }
}
</script>

<style scoped>

</style>
