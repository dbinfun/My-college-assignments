<template>
  <div id="content" style="">
        <div>
          <el-tag>题目</el-tag><br>
          <el-input
            type="textarea"
            :autosize="{ minRows: 2, maxRows: 20}"
            placeholder="请输入内容"
            readonly="readonly"
            :value="otherData.content">
          </el-input>
        </div>
    <div>
      <el-divider></el-divider>
      <el-tag type="success">回答</el-tag>
      <el-input
        type="textarea"
        :autosize="{ minRows: 2, maxRows: 20}"
        placeholder="请输入内容"
        v-model="pojo.content">
      </el-input>
    </div>
    <div style="width: 300px">
    <el-upload
      class="upload-demo"
      drag
      :action="uploadUrl"
      :on-success="upload_success"
      :data="otherData"
      :limit=1
      :headers="header"
      :on-exceed="on_exceed"
      :on-error="on_error"
      :before-remove="before_remove"
      multiple>
      <i class="el-icon-upload"></i>
      <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
      <div class="el-upload__tip" slot="tip">最大上传100MB的附件</div>
    </el-upload>
      <el-divider></el-divider>
      <el-form>
      <el-form-item v-if="pojo.filename" label="上次提交的附件">
        <span>{{pojo.filename}}</span>
        <el-button @click="download(pojo.href,pojo.filename)">下载附件</el-button>
      </el-form-item>
        <el-tag v-else type="danger">无提交历史</el-tag><br>
        <el-divider></el-divider>
      </el-form>
      <template>
        <div v-if="pojo.opinion.length>0&&pojo.fraction!=null">
        <span >分数:{{ pojo.fraction }}</span>
          <el-form>
            <el-form-item label="评语">
              <span>{{pojo.opinion}}</span>
            </el-form-item>
          </el-form>
          <el-divider></el-divider>
        </div>
      </template>
    </div>
    <el-button type="primary" @click="submit" plain>提交作业</el-button><el-button type="primary" @click="back()">返回</el-button>
  </div>
</template>

<script>
export default {
  name: "Test",
  beforeRouteEnter:(to,from,next)=>{
    next(vm=>{
      vm.getHomework(vm.$route.params.homeworkId)
    })
  },
  data(){
    return{
      uploadUrl: this.$axios.defaults.baseURL+"/api/uploadFile",
      otherData: {
        userId: 1,
        content: ""
      },
      header:{
        token: localStorage.getItem("token")
      },
      pojo:{
        homeworkId: -1,
        content: null,
        annex: null,
        opinion: '',
        fraction: '',
      }
    }
  },
  methods:{
    upload_success(res){
      //此处添加url信息
      this.pojo.annex = res.data.url;
    },
    on_exceed(){
      this.$message({
        message: "只能上传一个附件,请删除后重试",
        type: 'error'
      });
    },
    on_error(err, file, fileList){
      console.log(err)
      console.log(file)
      console.log(fileList)
      this.$message({
        message: "上传失败",
        type: 'error'
      });
    },
    before_remove(){
      this.$message({
        message: "已删除该文件",
        type: 'error'
      });
      //此处删除url连接
      this.pojo.annex=null;
    },
    submit(){
      console.log(this.pojo);
      var that = this;
      this.$axios(
        {
          method: 'post',
          url: '/api/user/homework/add',
          data: that.pojo,
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }
        //{`/api/user?page=${this.currentPage}&size=${this.size}`}
      ).then(response=>{
        that.$message.success(response.data.message);
        that.$router.go(0);
      }).catch(function (error){
        that.$message.error(error.response.data.message);
      })
    },
    getHomework(id){
      var that = this;
      this.$axios(
        {
          method: 'get',
          url: '/api/user/homework/getStu',
          params:{
            homeworkId: id,
          },
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }
        //{`/api/user?page=${this.currentPage}&size=${this.size}`}
      ).then(response=>{
        console.log(response.data.records);
        if(response.data.records.length>0) {
          that.pojo = response.data.records[0];
          that.pojo.filename = that.pojo.annex.substring(that.pojo.annex.indexOf('.') + 1)
          that.pojo.href = that.$axios.defaults.baseURL + that.pojo.annex;
        }
      }).catch(function (error){
        that.$message.error(error.response.data.message);
      })
    },
    download(t,filename){
      this.$axios({
          headers: {'token': localStorage.getItem('token')},
          responseType: 'blob',
          method: "get",
          url: t,
        }
      ).then(res => {
        const blob = new Blob([res.data]);//处理文档流
        const elink = document.createElement('a');
        elink.download = filename;
        elink.style.display = 'none';
        elink.href = URL.createObjectURL(blob);
        document.body.appendChild(elink);
        elink.click();
        URL.revokeObjectURL(elink.href); // 释放URL 对象
        document.body.removeChild(elink);
      }).catch(function (error) {

      })
    },
    back(){
      this.$router.replace('/home/mycourse')
    }
  },
  mounted() {
    this.pojo.homeworkId = parseInt(this.$route.params.homeworkId);
    this.otherData.content = this.$route.params.content;
    console.log(this.pojo.homeworkId);
  }
}
</script>

<style scoped>
#content{
  position: absolute;
  left: 50%;
  width: 40%;
  transform: translate(-50%,0%);
}
</style>
