<template>
  <div style="width: 100%;height: 100%;overflow: auto">
    <span>课程名:{{this.$route.params.courseName}}</span>
    <el-divider></el-divider>
    <el-form :inline="true">
      <el-button type="primary" @click="pojo={},formVisible=true">新增</el-button>
      <el-button type="primary" @click="backF()">返回</el-button>
    </el-form>

    <el-table
      :data="tableData"
      border
      style="width: 100%">
      <el-table-column
        show-overflow-tooltip
        prop="content"
        label="作业题目"
        width="200">
      </el-table-column>
      <el-table-column
        prop="endTime"
        label="截至时间"
        width="200">
      </el-table-column>
      <el-table-column
        label="操作"
        width="300">
        <template slot-scope="scope">
          <el-button type="primary" round @click="edit(scope.row)" size="small">修改</el-button>
          <el-button type="danger" round @click="dele(scope.row)" size="small">删除</el-button>
          <el-button type="primary" round @click="uhs(scope.row)" size="small">作业情况</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      @size-change="fetchData"
      @current-change="fetchData"
      :current-page.sync="currentPage"
      :page-sizes="[10, 20, 30, 40]"
      :page-size="size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total">
    </el-pagination>

    <el-dialog
      title="编辑作业"
      :visible.sync="formVisible">
      <el-form label-width="80px" show-overflow-tooltip>
        <el-form-item label="作业内容">
          <el-input maxlength="255" type="textarea" placeholder="作业内容" v-model="pojo.content"></el-input>
        </el-form-item>

        <el-form-item label="截至时间">
          <el-date-picker
            v-model="pojo.endTime"
            value-format="yyyy-MM-dd HH:mm:ss"
            type="datetime"
            placeholder="选择日期时间">
          </el-date-picker>
        </el-form-item>

        <el-form-item>
          <el-button @click="save()">保存</el-button>
          <el-button @click="formVisible = false">关闭</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "User",
  data(){
    return{
      tableData:[
        {
          id:1,
          createTime: '2022-1-1 00:00:00',
          endTime: '2022-1-1 00:00:00',
          content: '这是第一次作业饥荒艰苦撒旦克里夫金克拉几十块的金发科技上课酒店房卡深刻理解的饭卡上的JFK拉丝机打开链接付款了a'
        },
        {
          id:2,
          createTime: '2022-1-1 00:00:00',
          endTime: '2022-1-1 00:00:00',
          content: '这是第二次作业'
        }
      ],
      currentPage:1,
      size:10,
      total:10,
      formVisible:false,
      courseId: 1,
      pojo:{
        courseDescript: '',
        courseName: null
      },
      isEdit: false
    }
  },
  created(){
    this.courseId=this.$route.params.courseId;
    this.fetchData()
  },
  methods:{
    refresh(){
      this.searchMap={};
      this.fetchData();
    },
    fetchData(){
      var that = this;
      that.$axios(
        {
          method: 'get',
          url: '/api/homework/get',
          params:{
            current: that.currentPage,
            size: that.size,
            courseId: that.courseId
          },
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }
        //{`/api/user?page=${this.currentPage}&size=${this.size}`}
      ).then(response=>{
        this.tableData=response.data.records;
        this.total=response.data.total;
      }).catch(function (error){
        that.open("错误",error.response.data.message);
      })
    },
    save(){
      var that = this;
      that.pojo.courseId=this.$route.params.courseId;
        this.$axios({
            headers: {'token': localStorage.getItem('token')},
            responseType: 'json',
            method: "post",
            url: "/api/homework/add",
            data: that.pojo
          }
        ).then(response => {
          that.formVisible = false;
          that.fetchData();
          that.open("成功","");
        }).catch(function (error) {
          that.open("错误", error.response.data.message);
        })
    },
    edit(t){
      //打开窗口
      var that = this;
      that.pojo = JSON.parse(JSON.stringify(t));
      that.formVisible = true;
      that.isEdit=true;

    },
    dele(row){

      var that = this;
      //弹出提示
      this.$confirm('确定要删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then( ()=>{
        that.$axios({
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json',
          method: "post",
          url: "/api/homework/del",
          params: {id: row.id}
        }).then(response => {
          that.fetchData();
          that.open("成功","");
        }).catch(function (error) {
          that.open("错误", error.response.data.message);
        });
      });
    },
    open(title,message) {
      const h = this.$createElement;

      this.$notify({
        title: title,
        message: h('i', { style: 'color: red'}, message)
      });
    },
    uhs(t){
      this.$router.replace("/home/homeworkList/"+this.$route.params.courseId+"/"+t.id+"/"+this.$route.params.courseName+"/"+t.content);
    },
    backF(){
      this.$router.replace('/home/myteachcourse/');
    }
  }
}
</script>

<style scoped>

</style>
