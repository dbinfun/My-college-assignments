<template>
  <div style="width: 100%;height: 100%;overflow: auto">
    <div>
      <el-button type="primary" @click="back()" size="small">返回</el-button>
    </div>
    <el-table
      :data="tableData"
      border
      style="width: 100%">
      <el-table-column
        prop="user.username"
        label="用户名"
        width="200">
      </el-table-column>
      <el-table-column
        prop="user.nickName"
        label="昵称"
        width="200">
      </el-table-column>
      <el-table-column
        label="是否批改"
        width="200">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.fraction" type="success">已批</el-tag>
          <el-tag v-else type="danger">未批</el-tag>
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        width="200">
        <template slot-scope="scope">
          <el-button v-if="scope.row.fraction" type="primary" round @click="edit(scope.row)" size="small">修改</el-button>
          <el-button v-else type="primary" round @click="edit(scope.row)" size="small">批改</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      @size-change="fetchData"
      @current-change="fetchData"
      :current-page.sync="currentPage"
      :page-sizes="[10, 20, 30, 40]"
      :page-size="size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total">
    </el-pagination>

    <el-dialog
      title="批改"
      :visible.sync="formVisible">
      <el-form label-width="80px">
        <el-form-item label="作业内容">
          <el-input type="textarea" placeholder="" readonly="readonly" v-model="pojo.content"></el-input>
        </el-form-item>

        <el-form-item label="附件">
          <span>{{pojo.filename}}</span>
          <el-button @click="download(pojo.href,pojo.filename)">下载附件</el-button>
        </el-form-item>

        <el-form-item label="评语">
          <el-input type="textarea" placeholder="" v-model="pojo.opinion"></el-input>
        </el-form-item>

        <el-form-item label="打分">
          <el-slider
            v-model="pojo.fraction"
            show-input>
          </el-slider>
        </el-form-item>

        <el-form-item>
          <el-button @click="save()">保存</el-button>
          <el-button @click="formVisible = false">关闭</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <div style="text-align: center">
      <el-progress type="dashboard"  :percentage="count.percentage" :color="count.colors"></el-progress>
      <br>
      <span>完成情况</span>
    </div>
    <div>
      <el-popover
        placement="right"
        width="400"
        trigger="click">
        <el-table :data="count.info.commitUser">
          <el-table-column width="150" property="username" label="用户名"></el-table-column>
          <el-table-column width="100" property="nickName" label="昵称"></el-table-column>
        </el-table>
        <el-button slot="reference">已完成名单</el-button>
      </el-popover>
      <el-popover
        placement="right"
        width="400"
        trigger="click">
        <el-table :data="count.info.noCommitUsers">
          <el-table-column width="150" property="username" label="用户名"></el-table-column>
          <el-table-column width="100" property="nickName" label="昵称"></el-table-column>
        </el-table>
        <el-button slot="reference">未完成名单</el-button>
      </el-popover>
      <el-button slot="reference" @click="downloadExcel()">导出Excel</el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: "User",
  data(){
    return{
      tableData:[{
        homeworkId: 1111,
        userId: 1111,
        content: 'kkkkkkk',
        annex: '/file/20221214/7/1/1670997164265.image.png',
        user:{
          nickName: "学2",
          username: "stu2"
        },
      }],
      currentPage:1,
      size:10,
      total:10,
      searchMap:{},
      formVisible:false,
      pojo:{
        homeworkId: -1,
        userId: -1,
        fraction: -1,
        opinion: ''
      },
      isEdit: false,
      homeworkId: -1,
      count: {
        percentage: 50,
        colors: [
          {color: '#f56c6c', percentage: 20},
          {color: '#e6a23c', percentage: 40},
          {color: '#5cb87a', percentage: 60},
          {color: '#1989fa', percentage: 80},
          {color: '#6f7ad3', percentage: 100}
        ],
        info:{
          allUserCount:2,
          commitUserCount:0,
          commitUser:[

        ],
          noCommitUsers:[
          {
            id:10,
            nickName:"学1",
            username:"stu1"
          },
          {
            id:11,
            nickName:"学2",
            username:"stu2"
          }
        ]
        }
      }
    }
  },
  created(){
    this.homeworkId = this.$route.params.homeworkId;
    this.fetchData()
    this.countHomeworkInfo();
  },
  methods:{
    refresh(){
      this.searchMap={};
      this.fetchData();
    },
    fetchData(){
      var that = this;
      this.$axios(
        {
          method: 'get',
          url: '/api/user/homework/get',
          params:{
            current: this.currentPage,
            size: this.size,
            homeworkId: this.homeworkId
          },
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }
      ).then(response=>{
        this.tableData=response.data.records;
        this.total=response.data.total;
      }).catch(function (error){
        that.open("错误",error.response.data.message);
      })
    },
    save(){
      var that = this;
      this.$axios(
        {
          method: 'post',
          url: '/api/user/homework/correcting',
          params:{
            homeworkId: that.pojo.homeworkId,
            userId: that.pojo.userId,
            opinion: that.pojo.opinion,
            fraction: that.pojo.fraction
          },
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }
        //{`/api/user?page=${this.currentPage}&size=${this.size}`}
      ).then(response=>{
        that.formVisible = false;
        that.fetchData();
      }).catch(function (error){
        that.open("错误",error.response.data.message);
      })
    },
    edit(t){
      //打开窗口
      var that = this;
      that.pojo = JSON.parse(JSON.stringify(t));
      try {
        that.pojo.filename = that.pojo.annex.substring(that.pojo.annex.indexOf('.')+1)
        that.pojo.href = that.$axios.defaults.baseURL+ that.pojo.annex;
      }catch (e){

      }
      that.formVisible = true;

    },
    open(title,message) {
      const h = this.$createElement;

      this.$notify({
        title: title,
        message: h('i', { style: 'color: red'}, message)
      });
    },
    download(t,filename){
      this.$axios({
          headers: {'token': localStorage.getItem('token')},
          responseType: 'blob',
          method: "get",
          url: t,
        }
      ).then(res => {
        const blob = new Blob([res.data]);//处理文档流
        const elink = document.createElement('a');
        elink.download = filename;
        elink.style.display = 'none';
        elink.href = URL.createObjectURL(blob);
        document.body.appendChild(elink);
        elink.click();
        URL.revokeObjectURL(elink.href); // 释放URL 对象
        document.body.removeChild(elink);
      }).catch(function (error) {

      })
    },
    back(){
      console.log("h")
      this.$router.replace("/home/addHomework/"+this.$route.params.courseId+"/"+this.$route.params.courseName);
    },
    countHomeworkInfo(){
      var that = this;
      this.$axios({
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json',
          method: "get",
          url: '/api/homework/count',
          params: {
            homeworkId: this.$route.params.homeworkId
          }
        }
      ).then(res => {
        console.log(res);
        that.count.percentage = Math.floor(res.data.commitUserCount/res.data.allUserCount*100);
        that.count.info.commitUser= res.data.commitUser;
        that.count.info.noCommitUsers = res.data.noCommitUsers;
      }).catch(function (error) {

      })
    },
    downloadExcel(){
      this.$axios({
          headers: {'token': localStorage.getItem('token')},
          responseType: 'blob',
          method: "get",
          url: "/api/user/homework/download",
          params:{
            homeworkId:this.$route.params.homeworkId,
          }
        }
      ).then(res => {
        const blob = new Blob([res.data]);//处理文档流
        const elink = document.createElement('a');
        elink.download = this.$route.params.homeworkName+".xlsx";
        elink.style.display = 'none';
        elink.href = URL.createObjectURL(blob);
        document.body.appendChild(elink);
        elink.click();
        URL.revokeObjectURL(elink.href); // 释放URL 对象
        document.body.removeChild(elink);
      }).catch(function (error) {

      })
    },
  }
}
</script>

<style scoped>

</style>
