<template>
  <div style="width: 100%;height: 100%;overflow: auto">
    <el-table
      :data="tableData"
      border
      style="width: 100%">
      <el-table-column
        show-overflow-tooltip
        prop="courseName"
        label="课程名称"
        width="200">
      </el-table-column>
      <el-table-column
        show-overflow-tooltip
        prop="courseDescription"
        label="课程描述"
        width="200">
      </el-table-column>
      <el-table-column
        label="操作"
        width="300">
        <template slot-scope="scope">
          <el-button type="primary" round @click="adS(scope.row)" size="small">选择学生</el-button>
          <el-button type="primary" @click="edit(scope.row)" size="small">查看/布置作业</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog
      title="选择学生"
      :visible.sync="formVisible2">
      <el-transfer v-model="userData.value" :data="userData.data"
                   :props="{
        key: 'id',
        label: `usernames`}"
                   :filterable="true">
      </el-transfer>
      <el-button type="primary" @click="subStu()">提交</el-button>
    </el-dialog>
    <el-pagination
      @size-change="fetchData"
      @current-change="fetchData"
      :current-page.sync="currentPage"
      :page-sizes="[10, 20, 30, 40]"
      :page-size="size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total">
    </el-pagination>
  </div>
</template>

<script>
export default {
  name: "User",
  data(){
    return{
      tableData:[
        {
          courseId:1,
          courseName: 'name1',
          courseDescript: '描述1',
          userId: 6
        },
        {
          courseId:2,
          courseName: 'name2',
          courseDescript: '描述2',
          userId: 6
        }
      ],
      currentPage:1,
      size:10,
      total:10,
      searchMap:{},
      formVisible:false,
      pojo:{
        courseDescript: '',
        courseName: null
      },
      isEdit: false,
      userData:{
        data: [{id: 0,usernames: '1:1号'},{id:2,usernames: '2:2号'}],
        value: [0],
        courseId: 0
      },
      page2:{
        total: 1,
        page: 1,
        size: 10,
        username: null,
      },
      formVisible2:false,
    }
  },
  created(){
    this.fetchData()
  },
  methods:{
    refresh(){
      this.searchMap={};
      this.fetchData();
    },
    fetchData(){
      var that = this;
      this.$axios(
        {
          method: 'get',
          url: '/api/course/mycourseT',
          params:{
            current: this.currentPage,
            size: this.size,
          },
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }
        //{`/api/user?page=${this.currentPage}&size=${this.size}`}
      ).then(response=>{
        this.tableData=response.data.records;
        this.total=response.data.total;
      }).catch(function (error){
        that.open("错误",error.response.data.message);
      })
    },
    edit(t){
      this.$router.replace("/home/addHomework/"+t.courseId+"/"+t.courseName);
    },
    open(title,message) {
      const h = this.$createElement;

      this.$notify({
        title: title,
        message: h('i', { style: 'color: red'}, message)
      });
    },
    adS(row){
      this.formVisible2 = true;
      this.page2.username=null;
      this.pageS();
      this.courseUser(row.courseId);
    },
    pageS(){
      var that = this;
      that.$axios({
        headers: {'token': localStorage.getItem('token')},
        responseType: 'json',
        method: "get",
        url: "/api/user/smallUser",
        params: {
          page: that.page2.page,
          size: -1,
          username: that.page2.username
        }
      }).then(response => {
        that.userData.data = response.data.records;
        for(let i =0;i<that.userData.data.length;i++){
          let t = that.userData.data[i];
          that.userData.data[i].usernames = t.username+":"+t.nickName;
        }
      }).catch(function (error) {
        that.open("错误", error.response.data.message);
      });
    },
    //求课程的用户
    courseUser(id){
      var that = this;
      that.userData.courseId =  id;
      that.$axios({
        headers: {'token': localStorage.getItem('token')},
        responseType: 'json',
        method: "get",
        params:{
          courseId: id,
        },
        url: "/api/user/courseUser",
      }).then(response => {
        that.userData.value = response.data.map((obj)=>obj.id);
      }).catch(function (error) {
        that.open("错误", error.response.data.message);
      });
    },
    subStu() {
      var that = this;
      that.$axios({
        headers: {'token': localStorage.getItem('token')},
        responseType: 'json',
        method: "post",
        params: {
          courseId: that.userData.courseId,
          userIds: that.userData.value.join(',')
        },
        url: "/api/user/updateCourseUsers",
      }).then(response => {
        that.formVisible2 = false;
      }).catch(function (error) {
        that.open("错误", error.response.data.message);
      });
    }
  }
}
</script>

<style scoped>

</style>
