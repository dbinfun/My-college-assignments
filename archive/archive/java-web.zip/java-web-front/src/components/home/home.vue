<template>
  <div class="block">
    <span class="demonstration"></span>
    <el-carousel height="600px">
      <el-carousel-item>
        <img class="imgsss" src="/static/image/1.jpg"/>
      </el-carousel-item>
      <el-carousel-item>
        <img class="imgsss" src="/static/image/1.jpg"/>
      </el-carousel-item>
      <el-carousel-item>
        <img class="imgsss" src="/static/image/1.jpg"/>
      </el-carousel-item>
      <el-carousel-item>
        <img class="imgsss" src="/static/image/1.jpg"/>
      </el-carousel-item>
      <el-carousel-item>
        <img class="imgsss" src="/static/image/1.jpg"/>
      </el-carousel-item>
    </el-carousel>
  </div>
</template>

<script>
  export default{
    data(){
      return{

      }
    }
  }
</script>

<style scoped>
.el-carousel__item h3 {
  color: #475669;
  font-size: 14px;
  opacity: 0.75;
  margin: 0;
}

</style>
