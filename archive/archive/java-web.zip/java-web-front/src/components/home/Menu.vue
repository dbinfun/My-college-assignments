<template>
  <div class="navMenu">
    <template v-for="navMenu in navMenus" :default-openeds='[0]'>
        <!-- 最后一级菜单 -->
      <el-menu-item style="" v-if="(!navMenu.childs)||(navMenu.childs.length==0)"
                    :key="navMenu.id" :data="navMenu" :index="navMenu.router"
                   >
        <i :class="navMenu.icon"></i>
        <span slot="title">{{navMenu.name}}</span>
      </el-menu-item>

      <!-- 此菜单下还有子菜单 -->
      <el-submenu v-if="navMenu.childs&&navMenu.childs.length!=0"
                  :key="navMenu.id" :data="navMenu" :index="navMenu.icon">
        <template slot="title">
          <i :class="navMenu.icon"></i>
          <span> {{navMenu.name}}</span>
        </template>
        <!-- 递归 -->
        <NavMenu :navMenus="navMenu.childs"></NavMenu>
      </el-submenu>
    </template>

  </div>
</template>

<script>
  export default {
    name: 'NavMenu',
    props: ['navMenus'],
    data() {
      return {}
    },
    methods: {}
  }
</script>

<style scoped>
  .navMenu{
    width: 100%;
    height: 100%;
    background-color: rgb(84,92,100);
  }
</style>
