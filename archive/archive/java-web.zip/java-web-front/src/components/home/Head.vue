<template>
  <div id="app">
    <el-dropdown style="float: right;margin-left: 0px;position: relative;right: 0px;top: 30px">
      <span class="el-dropdown-link">
        <i class="el-icon-arrow-down el-icon--right"></i>
      </span>
      <el-dropdown-menu slot="dropdown" style="background-color: rgba(1, 1, 1, 0);">
        <el-dropdown-item><el-button type="warning" plain @click="logout">退出登录</el-button></el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
    <div id="avatar" style="">
      <el-tooltip style="width: 50px;height: 50px;;background-color: rgba(1, 1, 1, 0); border: 0;padding: 0px;" class="item" effect="dark" :content="userInfo.username" placement="bottom">
        <el-button>
        <router-link to="/mine">
          <el-avatar :size="50" :src='userInfo.avatar'></el-avatar>
        </router-link>

       </el-button>
      </el-tooltip>


    </div>
    <div id="project" style="text-align: center;line-height: 50px;">作业管理系统</div>


  </div>
</template>

<script>
  export default {
    name: 'UserInfo',
    props: ['userInfo'],
    data() {
      return {}
    },
    methods: {
      logout() {
        var that = this;
        this.$confirm('退出登录?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          that.$axios({
            method: 'post',
            url: '/auth/logout',
            headers: {'token': localStorage.getItem('token')},
          }).then(function (response) {
          }).catch(function (error) {
          });
          this.$message({
            type: 'success',
            message: '已经登出!',
          });
          //此处发送请求登出.
          localStorage.removeItem("token");
          localStorage.removeItem("user");
          that.$router.replace('/');
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '取消登出'
          });
        });
      }
    }
  }
</script>

<style scoped>
  #id{
    width: 100%;
    height: 100%;
    background-color: rgba(255, 255, 255, 0);
  }
  #avatar{
    width: 50px;
    height: 50px;
    float: right;
    margin-right: 20px;
    text-align: center;
    margin-right: 10px;
  }
  #username{
    float: right;
    bottom: 0px;
    height: 50px;
    margin-right: 10px;
    width: auto;
    display: flex;
    align-items: flex-end;
  }
</style>
