<template>
  <div style="width: 100%;height: 100%;overflow: auto">
    <el-form :inline="true">
      <el-form-item label="课程名">
        <el-input placeholder="课程名" v-model="searchMap.courseName"></el-input>
      </el-form-item>
      <el-button type="primary" @click="fetchData">查询</el-button>
      <el-button type="primary" @click="pojo={},formVisible=true">新增</el-button>
      <el-button type="primary" @click="refresh">重置刷新</el-button>
    </el-form>

    <el-table
      :data="tableData"
      border
      style="width: 100%">
      <el-table-column
        prop="courseName"
        label="课程名称"
        width="200">
      </el-table-column>
      <el-table-column
        prop="courseDescription"
        label="课程描述"
        width="200">
      </el-table-column>
      <el-table-column
        prop="userId"
        label="老师id"
        width="100">
      </el-table-column>
      <el-table-column
        prop="user.username"
        label="老师用户名"
        width="150">
      </el-table-column>
      <el-table-column
        prop="user.nickName"
        label="老师用户名"
        width="150">
      </el-table-column>
      <el-table-column
        label="分配学生"
        width="150">
        <template slot-scope="scope">
        <el-button type="primary" round @click="adS(scope.row)" size="small">选择学生</el-button>
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        width="200">
        <template slot-scope="scope">
          <el-button type="primary" round @click="edit(scope.row)" size="small">修改</el-button>
          <el-button type="danger" round @click="dele(scope.row)" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      @size-change="fetchData"
      @current-change="fetchData"
      :current-page.sync="currentPage"
      :page-sizes="[10, 20, 30, 40]"
      :page-size="size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total">
    </el-pagination>

    <el-dialog
      title="课程编辑"
      :visible.sync="formVisible">
      <el-form label-width="80px">
        <el-form-item label="课程名">
          <el-input placeholder="课程名" v-model="pojo.courseName"></el-input>
        </el-form-item>

        <el-form-item label="课程描述">
          <el-input placeholder="课程描述" v-model="pojo.courseDescription"></el-input>
        </el-form-item>

        <el-form-item label="老师">
          <el-input readonly="readonly" placeholder="老师" v-model="pojo.userId"></el-input>
        </el-form-item>
        <el-form-item label="老师昵称">
          <el-input readonly="readonly" placeholder="老师" v-model="pojo.nickName"></el-input>
        </el-form-item>

        <el-form-item>
          <el-popover
            placement="right"
            width="400"
            trigger="click">
            <el-input class="search-bar" placeholder="输入关键字" size="small" v-model="teacherSearch" @select="handleSelect" clearable/>
            <el-table ref="fieldsTable" class="more_btn" @select="selectCur" border  :data="teachersfilter"> <!--@selection-change="handleSelect"-->
              <el-table-column type="selection" width="55">

              </el-table-column>
              <el-table-column label="用户名">
                <template slot-scope="{row}">
                  <strong>{{row.username}}</strong>
                  <span></span>
                </template>
              </el-table-column>
              <el-table-column label="昵称">
                <template slot-scope="{row}">
                  <strong>{{row.nickName}}</strong>
                </template>
              </el-table-column>

            </el-table>
            <el-button slot="reference">选择老师</el-button>

          </el-popover>
          <el-button @click="save()">保存</el-button>
          <el-button @click="formVisible = false">关闭</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <el-dialog
      title="选择学生"
      :visible.sync="formVisible2">
      <el-transfer v-model="userData.value" :data="userData.data"
       :props="{
        key: 'id',
        label: `usernames`}"
        :filterable="true">
      </el-transfer>
      <el-button type="primary" @click="subStu()">提交</el-button>
<!--      <el-form :inline="true">
        <el-input placeholder="学生名" v-model="page2.username">
        </el-input>
        <el-button type="primary" @click="pageS()">查询</el-button>
        <el-button type="primary" @click="page2.username=null,adS()">重置刷新</el-button>
      </el-form>-->
<!--      <el-pagination
        small
        layout="prev, pager, next"
        :total="page2.total">
      </el-pagination>-->
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "User",
  data(){
    return{
      tableData:[
        {
          id:1,
          courseName: 'name1',
          courseDescription: '描述1',
          userId: 6
        },
        {
          id:2,
          courseName: 'name2',
          courseDescription: '描述2',
          userId: 6
        }
      ],
      currentPage:1,
      size:10,
      total:10,
      searchMap:{},
      formVisible:false,
      formVisible2:false,
      pojo:{
        courseDescription: '',
        courseName: '',
        userId: -1,
        nickName: ''
      },
      isEdit: false,
      userData:{
        data: [{id: 0,usernames: '1:1号'},{id:2,usernames: '2:2号'}],
        value: [0],
        courseId: 0
      },
      page2:{
        total: 1,
        page: 1,
        size: 10,
        username: null,
      },
      teachers:[
        {
          id: 1,
          username: 'tt',
          nickName: 'tt',
        },
        {
          id: 2,
          username: 'fff',
          nickName: 'www',
        }
      ],
      teacherSearch: ''
    }
  },
  created(){
    this.fetchData()
    this.teachS()
  },
  methods:{
    refresh(){
      this.searchMap={};
      this.fetchData();
    },
    fetchData(){
      var that = this;
      this.$axios(
        {
          method: 'get',
          url: '/api/course/get',
          params:{
            current: this.currentPage,
            size: this.size,
            courseName: this.searchMap.courseName
          },
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }
        //{`/api/user?page=${this.currentPage}&size=${this.size}`}
      ).then(response=>{
        this.tableData=response.data.records;
        this.total=response.data.total;
      }).catch(function (error){
      })
    },
    save(){
      var that = this;
      console.log(this.pojo);
      if(that.isEdit) {
        that.isEdit=false;
        this.$axios({
            headers: {'token': localStorage.getItem('token')},
            responseType: 'json',
            method: "post",
            url: "/api/course/save",
            data: this.pojo
          }
        ).then(response => {
          that.formVisible = false;
          that.fetchData();
          that.open("成功","");
        }).catch(function (error) {
          that.open("错误", error.response.data.message);
        })
      }else {
        this.$axios({
            headers: {'token': localStorage.getItem('token')},
            responseType: 'json',
            method: "post",
            url: "/api/course/save",
            data: this.pojo
          }
        ).then(response => {
          that.formVisible = false;
          that.fetchData();
          that.open("成功","");
        }).catch(function (error) {
          that.open("错误", error.response.data.message);
        })
      }
    },
    edit(t){
      //打开窗口
      var that = this;
      console.log("lllll")
      that.pojo = JSON.parse(JSON.stringify(t));
      that.pojo.username = t.user.username;
      that.pojo.nickName =t.user.nickName;
      that.formVisible = true;
      that.isEdit=true;

    },
    dele(row){

      var that = this;
      //弹出提示
      this.$confirm('确定要删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then( ()=>{
        that.$axios({
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json',
          method: "post",
          url: "/api/course/del",
          params: {id: row.courseId}
        }).then(response => {
          that.fetchData();
          that.open("成功","");
        }).catch(function (error) {
          that.open("错误", error.response.data.message);
        });
      });
    },
    open(title,message) {
      const h = this.$createElement;

      this.$notify({
        title: title,
        message: h('i', { style: 'color: red'}, message)
      });
    },
    adS(row){
      this.formVisible2 = true;
      this.page2.username=null;
      this.pageS();
      this.courseUser(row.courseId);
    },
    pageS(){
      var that = this;
      that.$axios({
        headers: {'token': localStorage.getItem('token')},
        responseType: 'json',
        method: "get",
        url: "/api/user/smallUser",
        params: {
          page: that.page2.page,
          size: -1,
          username: that.page2.username
        }
      }).then(response => {
        that.userData.data = response.data.records;
        for(let i =0;i<that.userData.data.length;i++){
          let t = that.userData.data[i];
          that.userData.data[i].usernames = t.username+":"+t.nickName;
        }
      }).catch(function (error) {
        that.open("错误", error.response.data.message);
      });
    },
    //获取所有老师
    teachS(){
      var that = this;
      that.$axios({
        headers: {'token': localStorage.getItem('token')},
        responseType: 'json',
        method: "get",
        url: "/api/user/smallUser",
        params: {
          page: 1,
          size: -1,
          roleId:2
        }
      }).then(response => {
        that.teachers = response.data.records;
        for(let i =0;i<that.userData.data.length;i++){
          let t = that.userData.data[i];
          that.userData.data[i].usernames = t.username+":"+t.nickName;
        }
      }).catch(function (error) {
        that.open("错误", error.response.data.message);
      });
    },
    //求课程的用户
    courseUser(id){
      var that = this;
      that.userData.courseId =  id;
      that.$axios({
        headers: {'token': localStorage.getItem('token')},
        responseType: 'json',
        method: "get",
        params:{
          courseId: id,
        },
        url: "/api/user/courseUser",
      }).then(response => {
        that.userData.value = response.data.map((obj)=>obj.id);
      }).catch(function (error) {
        that.open("错误", error.response.data.message);
      });
    },
    subStu(){
      var that = this;
      that.$axios({
        headers: {'token': localStorage.getItem('token')},
        responseType: 'json',
        method: "post",
        params:{
          courseId: that.userData.courseId,
          userIds: that.userData.value.join(',')
        },
        url: "/api/user/updateCourseUsers",
      }).then(response => {
        that.formVisible2 = false;
      }).catch(function (error) {
        that.open("错误", error.response.data.message);
      });
    },
    handleSelect(){
      console.log("hello")
    },
    // 选择变化时
    selectCur(val, row) {
      /*console.log(val, 'val')
      console.log(row, 'row')*/
      this.$refs.fieldsTable.clearSelection()
      this.$refs.fieldsTable.toggleRowSelection(row, true)
      this.pojo.userId = row.id;
      this.pojo.nickName = row.nickName;
    },

  },
  computed:{
    teachersfilter:function (){
      var search=this.teacherSearch;
      if(search){
        return  this.teachers.filter(function(dataNews){
          return Object.keys(dataNews).some(function(key){
            return String(dataNews[key]).toLowerCase().indexOf(search) > -1
          })
        })
      }
      return this.teachers;
    }
  }
}
</script>

<style scoped>
.more_btn thead .el-table-column--selection .cell {
  display: none;
}
</style>
