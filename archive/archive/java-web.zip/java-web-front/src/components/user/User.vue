<template>
  <div style="width: 100%;height: 100%;overflow: auto">
    <el-form :inline="true">
      <el-form-item label="用户名">
        <el-input placeholder="用户名" v-model="searchMap.username"></el-input>
      </el-form-item>
      <el-form-item label="昵称">
        <el-input placeholder="昵称" v-model="searchMap.nickName"></el-input>
      </el-form-item>
      <el-form-item label="身份">
        <el-select v-model="searchMap.roleId" placeholder="请选身份">
          <el-option label="无条件" :value="null"></el-option>
          <el-option label="老师" :value="2"></el-option>
          <el-option label="学生" :value="3"></el-option>
          <el-option label="管理(预留)" :value="1"></el-option>
        </el-select>
      </el-form-item>
      <el-button type="primary" @click="fetchData">查询</el-button>
      <el-button type="primary" @click="pojo={},formVisible=true">新增</el-button>
      <el-button type="primary" @click="refresh">重置刷新</el-button>
    </el-form>

    <el-table
      :data="tableData"
      border
      style="width: 100%">
      <el-table-column
        prop="id"
        label="id"
        width="200">
      </el-table-column>
      <el-table-column
        prop="username"
        label="用户名"
        width="200">
      </el-table-column>
      <el-table-column
        prop="nickName"
        label="昵称"
        width="200">
      </el-table-column>
      <el-table-column
        label="身份"
        width="200">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.roleId==2" type="success">老师</el-tag>
          <el-tag v-else-if="scope.row.roleId==3">学生</el-tag>
          <el-tag v-else type="danger">管理</el-tag>
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        width="200">
        <template slot-scope="scope">
          <el-button type="primary" round @click="edit(scope.row)" size="small">修改</el-button>
          <el-button type="danger" round @click="dele(scope.row)" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      @size-change="fetchData"
      @current-change="fetchData"
      :current-page.sync="currentPage"
      :page-sizes="[10, 20, 30, 40]"
      :page-size="size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total">
    </el-pagination>

    <el-dialog
      title="用户编辑"
      :visible.sync="formVisible">
      <el-form label-width="80px">
        <el-form-item label="用户名">
          <el-input placeholder="用户名" v-model="pojo.username"></el-input>
        </el-form-item>

        <el-form-item label="昵称">
          <el-input placeholder="昵称" v-model="pojo.nickName"></el-input>
        </el-form-item>

        <el-form-item label="身份">
          <el-select v-model="pojo.roleId" placeholder="请选身份">
            <el-option label="老师" :value="2"></el-option>
            <el-option label="学生" :value="3"></el-option>
            <el-option label="管理(预留)" :value="1"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button @click="save()">保存</el-button>
          <el-button @click="formVisible = false">关闭</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "User",
  data(){
    return{
      tableData:[],
      currentPage:1,
      size:10,
      total:10,
      searchMap:{},
      formVisible:false,
      pojo:{},
      isEdit: false
    }
  },
  created(){
    this.fetchData()
  },
  methods:{
    refresh(){
      this.searchMap={};
      this.fetchData();
    },
    fetchData(){
      var that = this;
      this.$axios(
        {
          method: 'get',
          url: '/api/user',
          params:{
            current: this.currentPage,
            size: this.size,
            username: this.searchMap.username,
            nickName: this.searchMap.nickName,
            roleId: this.searchMap.roleId
          },
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }
        //{`/api/user?page=${this.currentPage}&size=${this.size}`}
        ).then(response=>{
        this.tableData=response.data.records;
        this.total=response.data.total;
      }).catch(function (error){
        that.open("错误",error.response.data.message);
      })
    },
    save(){
      var that = this;
      if(that.isEdit) {
        that.isEdit=false;
        this.$axios({
            headers: {'token': localStorage.getItem('token')},
            responseType: 'json',
            method: "post",
            url: "/api/user/edit",
            data: this.pojo
          }
        ).then(response => {
          that.formVisible = false;
          that.fetchData();
          that.open("成功","");
        }).catch(function (error) {
          that.open("错误", error.response.data.message);
        })
      }else {
        this.$axios({
            headers: {'token': localStorage.getItem('token')},
            responseType: 'json',
            method: "post",
            url: "/api/user/save",
            data: this.pojo
          }
        ).then(response => {
          that.formVisible = false;
          that.fetchData();
          that.open("成功","初始密码123456");
        }).catch(function (error) {
          that.open("错误", error.response.data.message);
        })
      }
    },
    edit(t){
      //打开窗口
      var that = this;
      that.pojo = JSON.parse(JSON.stringify(t));
      that.formVisible = true;
      that.isEdit=true;

    },
    dele(row){

      var that = this;
      //弹出提示
      this.$confirm('确定要删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then( ()=>{
          that.$axios({
              headers: {'token': localStorage.getItem('token')},
              responseType: 'json',
              method: "post",
              url: "/api/user/delete",
              params: {ids: row.id}
            }).then(response => {
            that.fetchData();
            that.open("成功","");
          }).catch(function (error) {
            that.open("错误", error.response.data.message);
          });
      });
      //   .then( ()=>{
      //   that.$axios({
      //       headers: {'token': localStorage.getItem('token')},
      //       responseType: 'json',
      //       method: "post",
      //       url: "/api/user/delete",
      //       params: row.id
      //     }
      //   ).then(response => {
      //     that.formVisible = false;
      //     that.fetchData();
      //     that.open("成功","");
      //   }).catch(function (error) {
      //     that.open("错误", error.response.data.message);
      //   })
      // });
    },
    open(title,message) {
      const h = this.$createElement;

      this.$notify({
        title: title,
        message: h('i', { style: 'color: red'}, message)
      });
    }

  }
}
</script>

<style scoped>

</style>
