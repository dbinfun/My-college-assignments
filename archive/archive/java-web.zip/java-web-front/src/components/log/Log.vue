<template>
  <div style="">
    <div class="block">
      <span class="demonstration"> 清理日志 </span>
      <el-date-picker
        v-model="endtime"
        type="date"
        value-format="yyyy-MM-dd HH:mm:ss"
        placeholder="清理日期之前的日志">
      </el-date-picker>
      <el-button type="danger" @click="cleanLog">删除日志</el-button>
      <span class="demonstration">筛选日志:</span>
      <el-date-picker
        v-model="times"
        type="datetimerange"
        value-format="yyyy-MM-dd HH:mm:ss"
        :picker-options="pickerOptions"
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        align="right">
      </el-date-picker>
      <el-button type="primary" @click="searchLog">搜索</el-button>
      <el-button type="warning" @click="resetTime">全部重置</el-button>
    </div>

    <el-table
      class="noscorll"
      :stripe="true"
      :data="tableData.records"
      ref="expandTable"
      style="width: 100%;overflow: auto;height: 80%;">
      <el-table-column type="expand">
        <template slot-scope="scope">
          <el-form label-position="left" class="demo-table-expand">
            <el-form-item label="请求方法">
              <span>{{ scope.row.methodName }}</span>
            </el-form-item>
            <el-form-item label="请求参数">
              <span v-if="scope.row.params">{{ scope.row.params }}</span>
              <span v-else>无</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column
        label="用户名"
        width="200">
        <template slot-scope="scope">
          <span v-if="scope.row.username">{{scope.row.username}}</span>
          <span v-else>未登录</span>
        </template>
      </el-table-column>
      <el-table-column
        width="200"
        prop="description"
        label="操作">
      </el-table-column>
      <el-table-column
        width="150"
        label="ip">
        <template slot-scope="scope">
          <span v-if="scope.row.address">{{scope.row.address}}</span>
          <span v-else>未知</span>
        </template>
      </el-table-column>
      <el-table-column
        width="150"
        label="请求时间">
        <template slot-scope="scope">
          {{new Date(scope.row.requestTime).toLocaleString()}}
        </template>
      </el-table-column>
      <el-table-column
        width="150"
        label="请求耗时">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.elapsedTime>3000" type="danger">{{scope.row.elapsedTime}}ms</el-tag>
          <el-tag v-else-if="scope.row.elapsedTime>1000" type="warning">{{scope.row.elapsedTime}}ms</el-tag>
          <el-tag v-else type="success">{{scope.row.elapsedTime}}ms</el-tag>
        </template>
      </el-table-column>
      <el-table-column
        width="150"
        label="详细信息">
        <template slot-scope="scope">
          <el-button
            size="mini"
            @click="logInfo(scope.row)">详情</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div style="text-align: center;">
    <el-pagination
    @current-change="handleCurrentChange"
      background
      layout="prev, pager, next"
      :page-count="tableData.pages"
      :current-page="tableData.current"
      style="">
    </el-pagination>

    </div>
  </div>
</template>

<script>
  export default{
    name: "log",
    created(){
      this.getLog(this);
    },
    mounted() {
        // tableData是从后台获取，则这个遍历就放在获取tableData那个地方
          this.tableData.records.forEach(val => {
          this.$set(val, "expanded", false);
        });
      },
    methods: {
      getLog(vm){
        const that = vm;
        that.$axios({
          method: 'get',
          url: '/api/log',
          params:{
            current: 1,
            size: vm.size,

          },
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }).then(function (response) {
            console.log(response.data);
            that.$set(that,'tableData',response.data);
          })
          .catch(function (error) {
            const h = that.$createElement;
            that.$notify({
              title: '错误',
              message: h('i', { style: 'color: teal'}, '连接失败')
            });
          });
      },
      logInfo(row){
       row.expanded = !row.expanded;
       this.$refs.expandTable.toggleRowExpansion(row, row.expanded);
      },
      handleCurrentChange(newVal, oldVal){
        var that = this;
        let temp = {
          current: newVal,
          size: that.size
        };
        if(that.times[0]!=undefined&&this.times[1]!=undefined&&this.times[0]!=''&&this.times[1]!=''){
          temp.times=that.times[0]+","+this.times[1];
        }
        that.$axios({
          method: 'get',
          url: '/api/log',
          params: temp,
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }).then(function (response) {
            console.log(response.data);
            that.$set(that,'tableData',response.data);
          })
          .catch(function (error) {
            const h = that.$createElement;
            that.$notify({
              title: '错误',
              message: h('i', { style: 'color: teal'}, '连接失败')
            });
          });
      },
      cleanLog(){
        if(this.endtime==undefined||this.endtime==''){
          this.$message.error('请选择日期');
          return;
        }
        this.$confirm('确认删除'+this.endtime+"之前的日志？")
          .then(_ => {
            var that = this;
            that.$axios({
              method: 'post',
              url: '/api/log/clean',
              params:{
                end: that.endtime
              },
              headers: {'token': localStorage.getItem('token')},
              responseType: 'json'
            }).then(function (response) {
              that.getLog(that);
            })
              .catch(function (error) {
                const h = that.$createElement;
                that.$notify({
                  title: '错误',
                  message: h('i', { style: 'color: teal'}, '连接失败')
                });
              });
          })
          .catch(_ => {});


      },
      searchLog(){
        var that = this;
        let temp = {
          current: 1,
          size: that.size
        };
        if(that.times[0]!=undefined&&this.times[1]!=undefined&&this.times[0]!=''&&this.times[1]!=''){
          temp.times=that.times[0]+","+this.times[1];
        }
        that.$axios({
          method: 'get',
          url: '/api/log',
          params: temp,
          headers: {'token': localStorage.getItem('token')},
          responseType: 'json'
        }).then(function (response) {
          that.$set(that,'tableData',response.data);
        })
          .catch(function (error) {
            const h = that.$createElement;
            that.$notify({
              title: '错误',
              message: h('i', { style: 'color: teal'}, '连接失败')
            });
          });
      },
      resetTime(){
        this.times = '';
        this.endtime = '';
        this.getLog(this);
      }
    },
    data(){
      return{
        tableData: {
          records: [{
            id: 228,
            type: 0,
            userId: 1,
            username: "admin",
            description: "用户登录",
            browse: "ApiPOST Runtime +https://www.apipost.cn",
            address: "127.0.0.1",
            methodName: "cn.ourweb.java.modules.security.rest.AuthController.login()",
            params: {username:"admin"},
            exception: null,
            requestTime: 1669337901000,
            elapsedTime: 0
          }
          ],
          current: 1,
          pages: 1
        },
        times: ['',''],
        endtime: '',
        size: 10,
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
              picker.$emit('pick', [start, end]);
            }
          }]
        }
      }
    }
  }
</script>

<style scoped>
  .el-table__header{
    width: 100% !important;
  }
  .el-table__body{
    width: 100% !important;
  }
  .demo-table-expand {
    font-size: 0;
  }
  .demo-table-expand label {
    width: 90px;
    color: #99a9bf;
  }
  .demo-table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 50%;
  }
  .noscorll::-webkit-scrollbar{display: none;}
</style>
