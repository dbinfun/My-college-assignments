import Vue from 'vue'
import Router from 'vue-router'
import Login from '../view/Login'
import Home from '../view/Home'
import NotFound from '../view/404'
Vue.use(Router)

export default new Router({
  base: process.env.BASE_URL,
  mode: 'hash',
  routes: [
    {
      path: '/',
      name: 'login',
      component: Login
    },
    {
      path: '/home',
      name: 'home',
      component: Home,
      children:[
        {
          path: "/",
          name: "h",
          component:()=> import("../components/home/home")
        },
        {
          path: 'log',
          name: "log",
          component:()=> import("../components/log/Log")
        },
        {
          path: 'roleManage',
          name: 'roleManage',
          component: ()=> import("../view/Login")
        },{
          path: 'usermanage',
          name: 'userManage',
          component: ()=> import('../components/user/User')
        },{
          path: 'mycourse',
          name: 'mycourse',
          component: ()=> import("../components/Student/MyCourse")
        },
        //课程分配
        {
          path: 'course',
          name: 'course',
          component: ()=> import("../components/Course")
        },
        //教师负责的课程
        {
          path: 'myteachcourse',
          name: 'tcourse',
          component: ()=>import("../components/teacher/myCourse")
        },
        //老师布置作业
        {
          path: 'addHomework/:courseId/:courseName',
          name: 'addHomework',
          component: ()=>import("../components/teacher/Homework")
        },
        //查看作业里欸包
        {
          path: 'homeworkList/:courseId/:homeworkId/:courseName/:homeworkName',
          name: 'homeworkList',
          component: ()=>import("../components/teacher/UserHomeWork")
        }
      ]
    },
    {
      path: '/mine',
      name: 'myPage',
      component: ()=>import("../view/Mine")
    },
    {
      path: '/homework/:homeworkId/:content',
      name: 'homework',
      component: ()=>import("../components/Student/Homework")
    },
    {
      path: "*",
      component: NotFound
    },
    {
      path: "/test",
      name: 'test',
      component: ()=>import("../components/teacher/UserHomeWork")
    }
  ]
})
